function main() {
    const canvas = document.querySelector("#glCanvas");
    // Initialize the GL context
    const gl = canvas.getContext("webgl");

    // Only continue if WebGL is available and working
    if (gl === null) {
        alert("Unable to initialize WebGL. Your browser or machine may not support it.");
        return;
    }

    // Vertex shader program
    const vsSource = `
    attribute vec4 aVertexPosition;
    attribute vec3 aVertexNormal; // ** LIGHTING **
    attribute vec4 aVertexColor;

    uniform mat4 uNormalMatrix; // ** LIGHTING **
    uniform mat4 uModelViewMatrix;
    uniform mat4 uProjectionMatrix;

    varying lowp vec4 vColor;
    varying highp vec3 vLighting; // ** LIGHTING **

    void main(void) {
        gl_Position = uProjectionMatrix * uModelViewMatrix * aVertexPosition;
        vColor = aVertexColor;

        // Apply lighting effect // ** LIGHTING **

        highp vec3 ambientLight = vec3(0.3,0.3,0.3); //ambient light location (1,1,1)
        highp vec3 directionalLightColor = vec3(1, 1, 1);
        highp vec3 directionalVector = normalize(vec3(0.85, 0.8, 0.75));

        highp vec4 transformedNormal = uNormalMatrix * vec4(aVertexNormal, 1.0);

        highp float directional = max(dot(transformedNormal.xyz, directionalVector), 0.0);
        vLighting = ambientLight + (directionalLightColor * directional);
    }
`;

    // Fragment shader program 
    const fsSource = `
    varying lowp vec4 vColor;
    varying highp vec3 vLighting; // ** LIGHTING **

    void main(void) {
        gl_FragColor = vec4(vColor.rgb * vLighting, vColor.a); // ** LIGHTING **
    }
`;

    // Initialize a shader program; this is where all the lighting
    // for the vertices and so forth is established.
    const shaderProgram = initShaderProgram(gl, vsSource, fsSource);

    // Collect all the info needed to use the shader program.
    // Look up which attribute our shader program is using
    // for aVertexPosition and look up uniform locations.
    const programInfo = {
        program: shaderProgram,
        attribLocations: {
            vertexPosition: gl.getAttribLocation(shaderProgram, 'aVertexPosition'),
            vertexNormal: gl.getAttribLocation(shaderProgram, 'aVertexNormal'), // ** LIGHTING **
            vertexColor: gl.getAttribLocation(shaderProgram, 'aVertexColor'),
        },
        uniformLocations: {
            projectionMatrix: gl.getUniformLocation(shaderProgram, 'uProjectionMatrix'),
            modelViewMatrix: gl.getUniformLocation(shaderProgram, 'uModelViewMatrix'),
            normalMatrix: gl.getUniformLocation(shaderProgram, 'uNormalMatrix'), // ** LIGHTING **
        }
    };

    // coordinate to draw box
    const positionsBox = [
        // Front face
        -1.0, -1.0,  1.0, // 0
        1.0, -1.0,  1.0, // 1
        1.0,  1.0,  1.0, // 2
        -1.0,  1.0,  1.0, // 3

        // Back face
        -1.0, -1.0, -1.0, // 4
        -1.0,  1.0, -1.0, // 5
        1.0,  1.0, -1.0, // 6
        1.0, -1.0, -1.0, // 7

        // Top face
        -1.0,  1.0, -1.0, // 8
        -1.0,  1.0,  1.0, // 9
        1.0,  1.0,  1.0, // 10
        1.0,  1.0, -1.0, // 11

        // Bottom face
        -1.0, -1.0, -1.0, // 12
        1.0, -1.0, -1.0, // 13
        1.0, -1.0,  1.0, // 14
        -1.0, -1.0,  1.0, // 15

        // Right face
        1.0, -1.0, -1.0, // 16
        1.0,  1.0, -1.0, // 17
        1.0,  1.0,  1.0, // 18
        1.0, -1.0,  1.0, // 19

        // Left face
        -1.0, -1.0, -1.0, // 20
        -1.0, -1.0,  1.0, // 21
        -1.0,  1.0,  1.0, // 22
        -1.0,  1.0, -1.0, // 23
    ];

    gl.clearColor(1.0, 1.0, 0.5, 1.0);  // Clear to black, fully opaque
    gl.clearDepth(1.0);                 // Clear everything
    gl.enable(gl.DEPTH_TEST);           // Enable depth testing
    gl.depthFunc(gl.LEQUAL);            // Near things obscure far things

    //fieldOfView = fieldOfView * Math.PI / 180;   // in radians
    const fieldOfView = 50 * Math.PI / 180;   // in radians
    const aspect = gl.canvas.clientWidth / gl.canvas.clientHeight;
    const zNear = 0.1;
    const zFar = 1000.0;
    const projectionMatrix = mat4.create();

    // note: glmatrix.js always has the first argument
    // as the destination to receive the result.
    var cameraMatrix = mat4.perspective(projectionMatrix,
                        fieldOfView,
                        aspect,
                        zNear,
                        zFar);

    // cameraMatrix transformation is inverse
    cameraMatrix = mat4.translate(cameraMatrix,cameraMatrix,[50, -10, -80]);   
    let cameraRotateDefault = 95 * 0.0174533;
    cameraMatrix = mat4.rotate(cameraMatrix,cameraMatrix,cameraRotateDefault,[1,1,1]);

    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT); // Clear the canvas before we start drawing on it.
    let modelViewMatrix = mat4.create(); // center of screen (original MV coordinate)

    
    
    
    
    //Color Session
    const whiteColor = [
        [1.0,  1.0,  1.0,  1.0,],    // front side
        [1.0,  1.0,  1.0,  1.0],    // back side
        [1.0,  1.0,  1.0,  1.0],    // top side 
        [0.906, 0.765,  0.667,  1.0],    // bottom side 
        [1.0,  1.0,  1.0,  1.0],    // right side
        [1.0,  1.0,  1.0,  1.0],    // left side
    ];

    const greyColor = [
        [0.91,  0.91,  0.91,  1.0,],    // front side
        [0.91,  0.91,  0.91,  1.0,],    // back side
        [0.91,  0.91,  0.91,  1.0,],    // top side 
        [0.906, 0.765,  0.667,  1.0],   // bottom side
        [0.91,  0.91,  0.91,  1.0,],    // right side
        [0.91,  0.91,  0.91,  1.0,],    // left side
    ];

    const darkOrangeColor = [
        [0.918,  0.427,  0.039,  1.0,],    // front side
        [0.918,  0.427,  0.039,  1.0,],    // back side
        [0.89,  0.408,  0.125,  1.0,],    // top side 
        [0.89,  0.408,  0.125,  1.0,],    // bottom side 
        [0.89,  0.408,  0.125,  1.0,],    // right side
        [0.89,  0.408,  0.125,  1.0,],    // left side
    ];

    const darkOrangeColor2 = [
        [0.878,  0.443,  0.063,  1.0,],    // front side
        [0.878,  0.443,  0.063,  1.0,],    // back side
        [0.89,  0.408,  0.125,  1.0,],    // top side 
        [0.89,  0.408,  0.125,  1.0,],    // bottom side 
        [1.0,  0.529,  0.051,  1.0,],    // right side
        [1.0,  0.529,  0.051,  1.0,],    // left side
    ];

    const darkerOrangeColor = [
        [0.765,  0.325,  0.047,  1.0,],    // front side
        [0.765,  0.325,  0.047,  1.0,],    // back side
        [0.765,  0.325,  0.047,  1.0,],    // top side 
        [0.765,  0.325,  0.047,  1.0,],    // bottom side 
        [0.918,  0.427,  0.039,  1.0,],    // right side
        [0.918,  0.427,  0.039,  1.0,],    // left side
    ];

    const blackColor = [
        [0.0,  0.0,  0.0,  1.0,],    // front side
        [1.0,  1.0,  1.0,  1.0,],    // back side
        [1.0,  1.0,  1.0,  1.0,],    // Face 3
        [1.0,  1.0,  1.0,  1.0,],    // Face 4
        [1.0,  1.0,  1.0,  1.0,],    // right side
        [1.0,  1.0,  1.0,  1.0,],    // left side
    ];

    const orangeColor = [
        [1.0,  0.529,  0.051,  1.0,],    // front side
        [1.0,  0.529,  0.051,  1.0,],    // back side
        [0.918,  0.427,  0.039,  1.0,],    // Face 3
        [1.0,  0.529,  0.051,  1.0,],    // Face 4
        [1.0,  0.529,  0.051,  1.0,],    // right side
        [1.0,  0.529,  0.051,  1.0,],    // left side
    ];

    const brightOrangeColor = [
        [1.0,  0.62,  0.18,  1.0,],    // front side
        [1.0,  0.62,  0.18,  1.0,],    // back side
        [1.0,  0.62,  0.18,  1.0,],    // Face 3
        [1.0,  0.62,  0.18,  1.0,],    // Face 4
        [1.0,  0.62,  0.18,  1.0,],    // right side
        [1.0,  0.62,  0.18,  1.0,],    // left side
    ];

    const darkGreyColor = [
        [1.0,  1.0,  1.0,  1.0,],    // front side
        [1.0,  1.0,  1.0,  1.0,],    // back side
        [0.741,  0.612,  0.553,  1.0,],    // Face 3
        [0.741,  0.612,  0.553,  1.0,],    // Face 4
        [0.765,  0.325,  0.047,  1.0,],    // right side
        [0.765,  0.325,  0.047,  1.0,],    // left side
    ];
    
    //mouth color
    const mouthGreyColor = [
        [0.91,  0.91,  0.91,  1.0,],    // front side
        [0.91,  0.91,  0.91,  1.0,],    // back side
        [0.918,  0.427,  0.039,  1.0,],    // Face 3
        [1.0,  0.604,  0.557,  1.0,],    // Face 4
        [0.97,  0.455,  0.024,  1.0,],    // right side
        [0.97,  0.455,  0.024,  1.0,],    // left side
    ];

    const mouthWhiteColor = [
        [0.941,  0.941,  0.941,  1.0,],    // front side
        [0.941,  0.941,  0.941,  1.0,],    // back side
        [0.91,  0.91,  0.91,  1.0,],    // Face 3
        [0.91,  0.91,  0.91,  1.0,],    // Face 4
        [0.91,  0.91,  0.91,  1.0,],    // right side
        [0.91,  0.91,  0.91,  1.0,],    // left side
    ];

    const mouthBlackColor = [
        [0.0,  0.0,  0.0,  1.0,],    // front side
        [0.0,  0.0,  0.0,  1.0,],    // back side
        [0.984,  0.659,  0.176,  1.0,],    // Face 3
        [0.984,  0.659,  0.176,  1.0,],    // Face 4
        [0.91,  0.91,  0.91,  1.0,],    // right side
        [0.91,  0.91,  0.91,  1.0,],    // left side
    ];
    
    //ear collor
    const earOrangeColor = [
        [0.91,  0.91,  0.91,  1.0,],    // front side
        [0.792,  0.322,  0.055,  1.0,],    // back side
        [0.0,  0.0,  0.0,  1.0,],    // Face 3
        [0.0,  0.0,  0.0,  1.0,],    // Face 4
        [0.792,  0.322,  0.055,  1.0,],    // right side
        [0.792,  0.322,  0.055,  1.0,],    // left side
    ];

    const earGreyColor = [
        [0.651,  0.549,  0.498,  1.0,],    // front side
        [0.792,  0.322,  0.055,  1.0,],    // back side
        [0.0,  0.0,  0.0,  1.0,],    // Face 3
        [0.0,  0.0,  0.0,  1.0,],    // Face 4
        [0.792,  0.322,  0.055,  1.0,],    // right side
        [0.792,  0.322,  0.055,  1.0,],    // left side
    ];

    const earBlackColor = [
        [0.91,  0.91,  0.91,  1.0,],    // front side
        [0.0,  0.0,  0.0,  1.0,],    // back side
        [0.0,  0.0,  0.0,  1.0,],    // Face 3
        [0.0,  0.0,  0.0,  1.0,],    // Face 4
        [0.0,  0.0,  0.0,  1.0,],    // right side
        [0.0,  0.0,  0.0,  1.0,],    // left side
    ];
    
    const darkGreyColor1 = [
        [0.741,  0.612,  0.553,  1.0,],    // front side
        [0.741,  0.612,  0.553,  1.0,],    // back side
        [0.741,  0.612,  0.553,  1.0,],    // Face 3
        [0.741,  0.612,  0.553,  1.0,],    // Face 4
        [0.765,  0.325,  0.047,  1.0,],    // right side
        [0.765,  0.325,  0.047,  1.0,],    // left side
    ];

    const fullBlackColor = [
        [0.0,  0.0,  0.0,  1.0,],    // front side
        [0.0,  0.0,  0.0,  1.0,],    // back side
        [0.0,  0.0,  0.0,  1.0,],    // Face 3
        [0.0,  0.0,  0.0,  1.0,],    // Face 4
        [0.0,  0.0,  0.0,  1.0,],    // right side
        [0.0,  0.0,  0.0,  1.0,],    // left side
    ];

    //leg color
    const legGreyColor = [
        [0.651,  0.549,  0.498,  1.0,],
        [0.651,  0.549,  0.498,  1.0,],
        [0.651,  0.549,  0.498,  1.0,],
        [0.651,  0.549,  0.498,  1.0,],
        [0.651,  0.549,  0.498,  1.0,],
        [0.651,  0.549,  0.498,  1.0,],
    ];

    const legBrownColor = [
        [0.318,  0.251,  0.196,  1.0,],
        [0.318,  0.251,  0.196,  1.0,],
        [0.318,  0.251,  0.196,  1.0,],
        [0.0,  0.0,  0.0,  1.0,],
        [1.0,  0.561,  0.18,  1.0,],
        [0.318,  0.251,  0.196,  1.0,],  
    ];

    const legBrownColor2 = [
        [0.318,  0.251,  0.196,  1.0,],
        [0.318,  0.251,  0.196,  1.0,],
        [0.318,  0.251,  0.196,  1.0,],
        [0.0,  0.0,  0.0,  1.0,],
        [0.0,  0.0,  0.0,  1.0,],
        [0.318,  0.251,  0.196,  1.0,],  
    ];

    const legLightBrownColor = [
        [1.0,  0.561,  0.18,  1.0,],
        [1.0,  0.561,  0.18,  1.0,],
        [1.0,  0.561,  0.18,  1.0,],
        [1.0,  0.561,  0.18,  1.0,],
        [1.0,  0.561,  0.18,  1.0,],
        [1.0,  0.561,  0.18,  1.0,],
    ];

    const legBlackCOlor = [
        [0.318,  0.251,  0.196,  1.0,],
        [0.318,  0.251,  0.196,  1.0,],
        [0.318,  0.251,  0.196,  1.0,],
        [0.318,  0.251,  0.196,  1.0,],
        [0.0,  0.0,  0.0,  1.0,],
        [0.318,  0.251,  0.196,  1.0,],
    ];

    const legGreyColor2 = [
        [0.651,  0.549,  0.498,  1.0,],    // front side
        [0.651,  0.549,  0.498,  1.0,],    // back side
        [0.651,  0.549,  0.498,  1.0,],    // Face 3
        [0.651,  0.549,  0.498,  1.0,],    // Face 4
        [0.651,  0.549,  0.498,  1.0,],    // right side
        [0.902,  0.431,  0.2,  1.0,],    // left side
    ];

    const softOrangeColor = [
        [0.902,  0.431,  0.2,  1.0,],
        [0.902,  0.431,  0.2,  1.0,],
        [0.902,  0.431,  0.2,  1.0,],
        [0.902,  0.431,  0.2,  1.0,],
        [0.902,  0.431,  0.2,  1.0,],
        [0.902,  0.431,  0.2,  1.0,],
    ];

    const legOrangeColor2 = [
        [0.878,  0.443,  0.063,  1.0,],
        [0.878,  0.443,  0.063,  1.0,],
        [0.89,  0.408,  0.125,  1.0,],
        [0.89,  0.408,  0.125,  1.0,],
        [1.0,  0.561,  0.18,  1.0,], 
        [0.902,  0.431,  0.2,  1.0,],
    ];

    const legDarkOrangeColor = [
        [0.878,  0.443,  0.063,  1.0,],
        [0.918,  0.427,  0.039,  1.0,],
        [0.89,  0.408,  0.125,  1.0,],
        [0.89,  0.408,  0.125,  1.0,],
        [0.89,  0.408,  0.125,  1.0,],
        [0.89,  0.408,  0.125,  1.0,],
    ];


    // DRAW FOX BODY - parent (Part Ayuni)
    
    var xParent = 0.0
    //1
    modelViewMatrix = mat4.create();

    mat4.rotateX(modelViewMatrix,modelViewMatrix,rotateX);   
    mat4.rotateY(modelViewMatrix,modelViewMatrix,rotateY);  
    mat4.rotateZ(modelViewMatrix,modelViewMatrix,rotateZ);  

   

    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent, 0.0, zPositionObj]);  // amount to translate
    
    const buffersBody1 = initBuffers(gl,positionsBox,darkOrangeColor);
    var axisToRotate = [0, 1, 0]; 
    drawScene(gl, programInfo, buffersBody1, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //2
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersBody2 = initBuffers(gl,positionsBox,brightOrangeColor);
    axisToRotate = [1, 0, 0]; 
    drawScene(gl, programInfo, buffersBody2, cubeRotation3, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //3
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersBody3 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersBody3, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //4
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersBody4 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersBody4, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //5
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent-2.0, 0.0, 0.0]);  // amount to translate

    const buffersBody5 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersBody5, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //6
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent-2.0, 0.0, 0.0]);  // amount to translate

    const buffersBody6 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersBody6, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //6.1
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent-0.0, 2.0, 0.0]);  // amount to translate

        const buffersBody6Y1 = initBuffers(gl,positionsBox,darkerOrangeColor);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersBody6Y1, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //6.2
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent-0.0, 2.0, 0.0]);  // amount to translate

        const buffersBody6Y2 = initBuffers(gl,positionsBox,darkOrangeColor2);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersBody6Y2, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //6.3
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent-0.0, 2.0, 0.0]);  // amount to translate

        const buffersBody6Y3 = initBuffers(gl,positionsBox,darkOrangeColor2);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersBody6Y3, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //6.4
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent-0.0, 2.0, 0.0]);  // amount to translate

        const buffersBody6Y4 = initBuffers(gl,positionsBox,darkOrangeColor2);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersBody6Y4, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //6.5
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent-0.0, 2.0, 0.0]);  // amount to translate

        const buffersBody6Y5 = initBuffers(gl,positionsBox,darkerOrangeColor);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersBody6Y5, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //6.6
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent-0.0, 2.0, 0.0]);  // amount to translate

        const buffersBody6Y6 = initBuffers(gl,positionsBox,darkerOrangeColor);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersBody6Y6, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //6.7
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent-0.0, 2.0, 0.0]);  // amount to translate

        const buffersBody6Y7 = initBuffers(gl,positionsBox,darkerOrangeColor);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersBody6Y7, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //6.8
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent-0.0, 2.0, 0.0]);  // amount to translate

        const buffersBody6Y8 = initBuffers(gl,positionsBox,darkOrangeColor2);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersBody6Y8, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //6.9
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent-0.0, 2.0, 0.0]);  // amount to translate

        const buffersBody6Y9 = initBuffers(gl,positionsBox,darkOrangeColor2);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersBody6Y9, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //6.10
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent-0.0, 2.0, 0.0]);  // amount to translate

        const buffersBody6Y10 = initBuffers(gl,positionsBox,darkOrangeColor2);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersBody6Y10, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //5.10
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+2.0, 0.0, 0.0]);  // amount to translate

            const buffersBody5Y10 = initBuffers(gl,positionsBox,darkOrangeColor2);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersBody5Y10, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //5.9
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, -2.0, 0.0]);  // amount to translate

            const buffersBody5Y9 = initBuffers(gl,positionsBox,brightOrangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersBody5Y9, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //5.8
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, -2.0, 0.0]);  // amount to translate

            const buffersBody5Y8 = initBuffers(gl,positionsBox,brightOrangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersBody5Y8, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //5.7
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, -2.0, 0.0]);  // amount to translate

            const buffersBody5Y7 = initBuffers(gl,positionsBox,darkOrangeColor2);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersBody5Y7, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //5.6
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, -2.0, 0.0]);  // amount to translate

            const buffersBody5Y6 = initBuffers(gl,positionsBox,darkOrangeColor2);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersBody5Y6, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //5.5
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, -2.0, 0.0]);  // amount to translate

            const buffersBody5Y5 = initBuffers(gl,positionsBox,darkOrangeColor2);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersBody5Y5, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //5.4
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, -2.0, 0.0]);  // amount to translate

            const buffersBody5Y4 = initBuffers(gl,positionsBox,darkOrangeColor2);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersBody5Y4, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //5.3
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, -2.0, 0.0]);  // amount to translate

            const buffersBody5Y3 = initBuffers(gl,positionsBox,brightOrangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersBody5Y3, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //5.2
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, -2.0, 0.0]);  // amount to translate

            const buffersBody5Y2 = initBuffers(gl,positionsBox,brightOrangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersBody5Y2, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //5.1
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, -2.0, 0.0]);  // amount to translate

            const buffersBody5Y1 = initBuffers(gl,positionsBox,darkOrangeColor2);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersBody5Y1, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //4.10
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+2.0, 0.0, 0.0]);  // amount to translate

                const buffersBody4Y10 = initBuffers(gl,positionsBox,darkOrangeColor2);
                axisToRotate = [0, 0, 0]; 
                drawScene(gl, programInfo, buffersBody4Y10, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //4.9
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, +2.0, 0.0]);  // amount to translate

                const buffersBody4Y9 = initBuffers(gl,positionsBox,darkOrangeColor2);
                axisToRotate = [0, 0, 0]; 
                drawScene(gl, programInfo, buffersBody4Y9, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //4.8
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, +2.0, 0.0]);  // amount to translate

                const buffersBody4Y8 = initBuffers(gl,positionsBox,darkOrangeColor2);
                axisToRotate = [0, 0, 0]; 
                drawScene(gl, programInfo, buffersBody4Y8, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //4.7
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, +2.0, 0.0]);  // amount to translate

                const buffersBody4Y7 = initBuffers(gl,positionsBox,darkOrangeColor2);
                axisToRotate = [0, 0, 0]; 
                drawScene(gl, programInfo, buffersBody4Y7, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //4.6
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, +2.0, 0.0]);  // amount to translate

                const buffersBody4Y6 = initBuffers(gl,positionsBox,darkOrangeColor2);
                axisToRotate = [0, 0, 0]; 
                drawScene(gl, programInfo, buffersBody4Y6, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //4.5
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, +2.0, 0.0]);  // amount to translate

                const buffersBody4Y5 = initBuffers(gl,positionsBox,darkOrangeColor2);
                axisToRotate = [0, 0, 0]; 
                drawScene(gl, programInfo, buffersBody4Y5, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //4.4
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, +2.0, 0.0]);  // amount to translate

                const buffersBody4Y4 = initBuffers(gl,positionsBox,darkOrangeColor2);
                axisToRotate = [0, 0, 0]; 
                drawScene(gl, programInfo, buffersBody4Y4, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //4.3
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, +2.0, 0.0]);  // amount to translate

                const buffersBody4Y3 = initBuffers(gl,positionsBox,darkOrangeColor2);
                axisToRotate = [0, 0, 0]; 
                drawScene(gl, programInfo, buffersBody4Y3, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //4.2
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, +2.0, 0.0]);  // amount to translate

                const buffersBody4Y2 = initBuffers(gl,positionsBox,brightOrangeColor);
                axisToRotate = [0, 0, 0]; 
                drawScene(gl, programInfo, buffersBody4Y2, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //4.1
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, +2.0, 0.0]);  // amount to translate

                const buffersBody4Y1 = initBuffers(gl,positionsBox,darkOrangeColor2);
                axisToRotate = [0, 0, 0]; 
                drawScene(gl, programInfo, buffersBody4Y1, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //3.10
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+2.0, 0.0, 0.0]);  // amount to translate

                    const buffersBody3Y10 = initBuffers(gl,positionsBox,darkOrangeColor2);
                    axisToRotate = [0, 0, 0]; 
                    drawScene(gl, programInfo, buffersBody3Y10, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //3.9
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, -2.0, 0.0]);  // amount to translate

                    const buffersBody3Y9 = initBuffers(gl,positionsBox,darkOrangeColor2);
                    axisToRotate = [0, 0, 0]; 
                    drawScene(gl, programInfo, buffersBody3Y9, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //3.8
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, -2.0, 0.0]);  // amount to translate

                    const buffersBody3Y8 = initBuffers(gl,positionsBox,brightOrangeColor);
                    axisToRotate = [0, 0, 0]; 
                    drawScene(gl, programInfo, buffersBody3Y8, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //3.7
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, -2.0, 0.0]);  // amount to translate

                    const buffersBody3Y7 = initBuffers(gl,positionsBox,brightOrangeColor);
                    axisToRotate = [0, 0, 0]; 
                    drawScene(gl, programInfo, buffersBody3Y7, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //3.6
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, -2.0, 0.0]);  // amount to translate

                    const buffersBody3Y6 = initBuffers(gl,positionsBox,darkOrangeColor2);
                    axisToRotate = [0, 0, 0]; 
                    drawScene(gl, programInfo, buffersBody3Y6, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //3.5
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, -2.0, 0.0]);  // amount to translate

                    const buffersBody3Y5 = initBuffers(gl,positionsBox,darkOrangeColor2);
                    axisToRotate = [0, 0, 0]; 
                    drawScene(gl, programInfo, buffersBody3Y5, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //3.4
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, -2.0, 0.0]);  // amount to translate

                    const buffersBody3Y4 = initBuffers(gl,positionsBox,darkOrangeColor2);
                    axisToRotate = [0, 0, 0]; 
                    drawScene(gl, programInfo, buffersBody3Y4, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //3.3
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, -2.0, 0.0]);  // amount to translate

                    const buffersBody3Y3 = initBuffers(gl,positionsBox,brightOrangeColor);
                    axisToRotate = [0, 0, 0]; 
                    drawScene(gl, programInfo, buffersBody3Y3, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //3.2
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, -2.0, 0.0]);  // amount to translate

                    const buffersBody3Y2 = initBuffers(gl,positionsBox,brightOrangeColor);
                    axisToRotate = [0, 0, 0]; 
                    drawScene(gl, programInfo, buffersBody3Y2, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //3.1
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, -2.0, 0.0]);  // amount to translate

                    const buffersBody3Y1 = initBuffers(gl,positionsBox,darkOrangeColor2);
                    axisToRotate = [0, 0, 0]; 
                    drawScene(gl, programInfo, buffersBody3Y1, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //2.10
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+2.0, 0.0, 0.0]);  // amount to translate

                        const buffersBody2Y10 = initBuffers(gl,positionsBox,darkOrangeColor2);
                        axisToRotate = [0, 0, 0]; 
                        drawScene(gl, programInfo, buffersBody2Y10, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //2.9
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, +2.0, 0.0]);  // amount to translate

                        const buffersBody2Y9 = initBuffers(gl,positionsBox,darkOrangeColor2);
                        axisToRotate = [0, 0, 0]; 
                        drawScene(gl, programInfo, buffersBody2Y9, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //2.8
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, +2.0, 0.0]);  // amount to translate

                        const buffersBody2Y8 = initBuffers(gl,positionsBox,orangeColor);
                        axisToRotate = [0, 0, 0]; 
                        drawScene(gl, programInfo, buffersBody2Y8, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //2.7
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, +2.0, 0.0]);  // amount to translate

                        const buffersBody2Y7 = initBuffers(gl,positionsBox,orangeColor);
                        axisToRotate = [0, 0, 0]; 
                        drawScene(gl, programInfo, buffersBody2Y7, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //2.6
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, +2.0, 0.0]);  // amount to translate

                        const buffersBody2Y6 = initBuffers(gl,positionsBox,darkOrangeColor2);
                        axisToRotate = [0, 0, 0]; 
                        drawScene(gl, programInfo, buffersBody2Y6, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //2.5
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, +2.0, 0.0]);  // amount to translate

                        const buffersBody2Y5 = initBuffers(gl,positionsBox,darkOrangeColor2);
                        axisToRotate = [0, 0, 0]; 
                        drawScene(gl, programInfo, buffersBody2Y5, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //2.4
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, +2.0, 0.0]);  // amount to translate

                        const buffersBody2Y4 = initBuffers(gl,positionsBox,darkOrangeColor2);
                        axisToRotate = [0, 0, 0]; 
                        drawScene(gl, programInfo, buffersBody2Y4, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //2.3
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, +2.0, 0.0]);  // amount to translate

                        const buffersBody2Y3 = initBuffers(gl,positionsBox,orangeColor);
                        axisToRotate = [0, 0, 0]; 
                        drawScene(gl, programInfo, buffersBody2Y3, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //2.2
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, +2.0, 0.0]);  // amount to translate

                        const buffersBody2Y2 = initBuffers(gl,positionsBox,orangeColor);
                        axisToRotate = [0, 0, 0]; 
                        drawScene(gl, programInfo, buffersBody2Y2, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //2.1
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, +2.0, 0.0]);  // amount to translate

                        const buffersBody2Y1 = initBuffers(gl,positionsBox,darkOrangeColor2);
                        axisToRotate = [0, 0, 0]; 
                        drawScene(gl, programInfo, buffersBody2Y1, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //1.10
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+2.0, 0.0, 0.0]);  // amount to translate

                            const buffersBody1Y10 = initBuffers(gl,positionsBox,orangeColor);
                            axisToRotate = [0, 0, 0]; 
                            drawScene(gl, programInfo, buffersBody1Y10, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0); 
                            //1.9
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, -2.0, 0.0]);  // amount to translate

                            const buffersBody1Y9 = initBuffers(gl,positionsBox,orangeColor);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody1Y9, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //1.8
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, -2.0, 0.0]);  // amount to translate

                            const buffersBody1Y8 = initBuffers(gl,positionsBox,darkOrangeColor2);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody1Y8, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //1.7
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, -2.0, 0.0]);  // amount to translate

                            const buffersBody1Y7 = initBuffers(gl,positionsBox,darkOrangeColor2);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody1Y7, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //1.6
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, -2.0, 0.0]);  // amount to translate

                            const buffersBody1Y6 = initBuffers(gl,positionsBox,darkOrangeColor2);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody1Y6, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //1.5
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, -2.0, 0.0]);  // amount to translate

                            const buffersBody1Y5 = initBuffers(gl,positionsBox,darkOrangeColor2);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody1Y5, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //1.4
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, -2.0, 0.0]);  // amount to translate

                            const buffersBody1Y4 = initBuffers(gl,positionsBox,orangeColor);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody1Y4, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //1.3
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, -2.0, 0.0]);  // amount to translate

                            const buffersBody1Y3 = initBuffers(gl,positionsBox,darkOrangeColor2);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody1Y3, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //1.2
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, -2.0, 0.0]);  // amount to translate

                            const buffersBody1Y2 = initBuffers(gl,positionsBox,darkOrangeColor2);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody1Y2, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //1.1
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, -2.0, 0.0]);  // amount to translate

                            const buffersBody1Y1 = initBuffers(gl,positionsBox,darkOrangeColor);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody1Y1, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);                    
    //1 side kiri
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xParent+0.0, -2.0, -2.0]);  // amount to translate

    const buffersBody1ZL = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0];; 
    drawScene(gl, programInfo, buffersBody1ZL, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //1.1 side kiri
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent+0.0, +0.0, -2.0]);  // amount to translate

        const buffersBody1ZL1 = initBuffers(gl,positionsBox,darkOrangeColor);
        axisToRotate = [0, 0, 0];; 
        drawScene(gl, programInfo, buffersBody1ZL1, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //1.2 side kiri
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent+0.0, +0.0, -2.0]);  // amount to translate

        const buffersBody1ZL2 = initBuffers(gl,positionsBox,darkOrangeColor);
        axisToRotate = [0, 0, 0];; 
        drawScene(gl, programInfo, buffersBody1ZL2, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //1.3 side kiri
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent+0.0, +0.0, -2.0]);  // amount to translate

        const buffersBody1ZL3 = initBuffers(gl,positionsBox,darkOrangeColor);
        axisToRotate = [0, 0, 0];; 
        drawScene(gl, programInfo, buffersBody1ZL3, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //1.4 side kiri
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent+0.0, +0.0, -2.0]);  // amount to translate

        const buffersBody1ZL4 = initBuffers(gl,positionsBox,darkOrangeColor);
        axisToRotate = [0, 0, 0];; 
        drawScene(gl, programInfo, buffersBody1ZL4, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //1.5 side kiri
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent+0.0, +0.0, -2.0]);  // amount to translate

        const buffersBody1ZL5 = initBuffers(gl,positionsBox,darkerOrangeColor);
        axisToRotate = [0, 0, 0];; 
        drawScene(gl, programInfo, buffersBody1ZL5, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //1.6 side kiri
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent+0.0, +0.0, -2.0]);  // amount to translate

        const buffersBody1ZL6 = initBuffers(gl,positionsBox,darkerOrangeColor);
        axisToRotate = [0, 0, 0];; 
        drawScene(gl, programInfo, buffersBody1ZL6, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //1.6.1 side kiri
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, +2.0, +0.0]);  // amount to translate

            const buffersBody1ZL6Y1 = initBuffers(gl,positionsBox,darkOrangeColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody1ZL6Y1, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //1.6.2 side kiri
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, +2.0, +0.0]);  // amount to translate

            const buffersBody1ZL6Y2 = initBuffers(gl,positionsBox,darkOrangeColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody1ZL6Y2, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //1.6.3 side kiri
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, +2.0, +0.0]);  // amount to translate

            const buffersBody1ZL6Y3 = initBuffers(gl,positionsBox,darkOrangeColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody1ZL6Y3, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //1.6.4 side kiri
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, +2.0, +0.0]);  // amount to translate

            const buffersBody1ZL6Y4 = initBuffers(gl,positionsBox,darkOrangeColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody1ZL6Y4, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //1.6.5 side kiri
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, +2.0, +0.0]);  // amount to translate

            const buffersBody1ZL6Y5 = initBuffers(gl,positionsBox,darkerOrangeColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody1ZL6Y5, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //1.6.6 side kiri
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, +2.0, +0.0]);  // amount to translate

            const buffersBody1ZL6Y6 = initBuffers(gl,positionsBox,darkerOrangeColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody1ZL6Y6, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //1.6.7 side kiri
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, +2.0, +0.0]);  // amount to translate

            const buffersBody1ZL6Y7 = initBuffers(gl,positionsBox,darkerOrangeColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody1ZL6Y7, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //1.6.8 side kiri
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, +2.0, +0.0]);  // amount to translate

            const buffersBody1ZL6Y8 = initBuffers(gl,positionsBox,darkOrangeColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody1ZL6Y8, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //1.6.9 side kiri
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, +2.0, +0.0]);  // amount to translate

            const buffersBody1ZL6Y9 = initBuffers(gl,positionsBox,darkOrangeColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody1ZL6Y9, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //1.6.10 side kiri
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, +2.0, +0.0]);  // amount to translate

            const buffersBody1ZL6Y10 = initBuffers(gl,positionsBox,darkOrangeColor2);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody1ZL6Y10, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //1.5.1 side kiri
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, -0.0, +2.0]);  // amount to translate

                const buffersBody1ZL5Y1 = initBuffers(gl,positionsBox,darkOrangeColor2);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody1ZL5Y1, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //1.5.2 side kiri
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                const buffersBody1ZL5Y2 = initBuffers(gl,positionsBox,darkOrangeColor2);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody1ZL5Y2, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //1.5.3 side kiri
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                const buffersBody1ZL5Y3 = initBuffers(gl,positionsBox,darkOrangeColor2);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody1ZL5Y3, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //1.5.4 side kiri
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                const buffersBody1ZL5Y4 = initBuffers(gl,positionsBox,darkerOrangeColor);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody1ZL5Y4, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //1.5.5 side kiri
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                const buffersBody1ZL5Y5 = initBuffers(gl,positionsBox,darkerOrangeColor);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody1ZL5Y5, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //1.5.6 side kiri
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                const buffersBody1ZL5Y6 = initBuffers(gl,positionsBox,orangeColor);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody1ZL5Y6, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //1.5.7 side kiri
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                const buffersBody1ZL5Y7 = initBuffers(gl,positionsBox,orangeColor);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody1ZL5Y7, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //1.5.8 side kiri
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                const buffersBody1ZL5Y8 = initBuffers(gl,positionsBox,darkerOrangeColor);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody1ZL5Y8, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //1.5.9 side kiri
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                const buffersBody1ZL5Y9 = initBuffers(gl,positionsBox,darkerOrangeColor);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody1ZL5Y9, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //1.5.10 side kiri
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                const buffersBody1ZL5Y10 = initBuffers(gl,positionsBox,darkerOrangeColor);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody1ZL5Y10, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //1.4.1 side kiri
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, -0.0, +2.0]);  // amount to translate

                    const buffersBody1ZL4Y1 = initBuffers(gl,positionsBox,darkOrangeColor2);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody1ZL4Y1, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //1.4.2 side kiri
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, +2.0, +0.0]);  // amount to translate

                    const buffersBody1ZL4Y2 = initBuffers(gl,positionsBox,darkOrangeColor2);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody1ZL4Y2, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //1.4.3 side kiri
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, +2.0, +0.0]);  // amount to translate

                    const buffersBody1ZL4Y3 = initBuffers(gl,positionsBox,darkOrangeColor);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody1ZL4Y3, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //1.4.4 side kiri
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, +2.0, +0.0]);  // amount to translate

                    const buffersBody1ZL4Y4 = initBuffers(gl,positionsBox,orangeColor);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody1ZL4Y4, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //1.4.5 side kiri
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, +2.0, +0.0]);  // amount to translate

                    const buffersBody1ZL4Y5 = initBuffers(gl,positionsBox,darkOrangeColor2);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody1ZL4Y5, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //1.4.6 side kiri
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, +2.0, +0.0]);  // amount to translate

                    const buffersBody1ZL4Y6 = initBuffers(gl,positionsBox,darkOrangeColor2);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody1ZL4Y6, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //1.4.7 side kiri
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, +2.0, +0.0]);  // amount to translate

                    const buffersBody1ZL4Y7 = initBuffers(gl,positionsBox,darkOrangeColor2);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody1ZL4Y7, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //1.4.8 side kiri
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, +2.0, +0.0]);  // amount to translate

                    const buffersBody1ZL4Y8 = initBuffers(gl,positionsBox,darkOrangeColor2);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody1ZL4Y8, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //1.4.9 side kiri
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, +2.0, +0.0]);  // amount to translate

                    const buffersBody1ZL4Y9 = initBuffers(gl,positionsBox,darkOrangeColor2);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody1ZL4Y9, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //1.4.10 side kiri
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, +2.0, +0.0]);  // amount to translate

                    const buffersBody1ZL4Y10 = initBuffers(gl,positionsBox,darkOrangeColor2);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody1ZL4Y10, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //1.3.1 side kiri
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, -0.0, +2.0]);  // amount to translate

                        const buffersBody1ZL3Y1 = initBuffers(gl,positionsBox,darkOrangeColor2);
                        axisToRotate = [0, 0, 0];; 
                        drawScene(gl, programInfo, buffersBody1ZL3Y1, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //1.3.2 side kiri
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, -2.0, +0.0]);  // amount to translate

                        const buffersBody1ZL3Y2 = initBuffers(gl,positionsBox,darkOrangeColor2);
                        axisToRotate = [0, 0, 0];; 
                        drawScene(gl, programInfo, buffersBody1ZL3Y2, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //1.3.3 side kiri
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, -2.0, +0.0]);  // amount to translate

                        const buffersBody1ZL3Y3 = initBuffers(gl,positionsBox,darkOrangeColor2);
                        axisToRotate = [0, 0, 0];; 
                        drawScene(gl, programInfo, buffersBody1ZL3Y3, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //1.3.4 side kiri
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, -2.0, +0.0]);  // amount to translate

                        const buffersBody1ZL3Y4 = initBuffers(gl,positionsBox,darkOrangeColor2);
                        axisToRotate = [0, 0, 0];; 
                        drawScene(gl, programInfo, buffersBody1ZL3Y4, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //1.3.5 side kiri
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, -2.0, +0.0]);  // amount to translate

                        const buffersBody1ZL3Y5 = initBuffers(gl,positionsBox,darkOrangeColor2);
                        axisToRotate = [0, 0, 0];; 
                        drawScene(gl, programInfo, buffersBody1ZL3Y5, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //1.3.6 side kiri
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, -2.0, +0.0]);  // amount to translate

                        const buffersBody1ZL3Y6 = initBuffers(gl,positionsBox,darkOrangeColor2);
                        axisToRotate = [0, 0, 0];; 
                        drawScene(gl, programInfo, buffersBody1ZL3Y6, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //1.3.7 side kiri
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, -2.0, +0.0]);  // amount to translate

                        const buffersBody1ZL3Y7 = initBuffers(gl,positionsBox,orangeColor);
                        axisToRotate = [0, 0, 0];; 
                        drawScene(gl, programInfo, buffersBody1ZL3Y7, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //1.3.8 side kiri
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, -2.0, +0.0]);  // amount to translate

                        const buffersBody1ZL3Y8 = initBuffers(gl,positionsBox,orangeColor);
                        axisToRotate = [0, 0, 0];; 
                        drawScene(gl, programInfo, buffersBody1ZL3Y8, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //1.3.9 side kiri
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, -2.0, +0.0]);  // amount to translate

                        const buffersBody1ZL3Y9 = initBuffers(gl,positionsBox,orangeColor);
                        axisToRotate = [0, 0, 0];; 
                        drawScene(gl, programInfo, buffersBody1ZL3Y9, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //1.3.10 side kiri
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, -2.0, +0.0]);  // amount to translate

                        const buffersBody1ZL3Y10 = initBuffers(gl,positionsBox,darkOrangeColor2);
                        axisToRotate = [0, 0, 0];; 
                        drawScene(gl, programInfo, buffersBody1ZL3Y10, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //1.2.1 side kiri
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, -0.0, +2.0]);  // amount to translate

                            const buffersBody1ZL2Y1 = initBuffers(gl,positionsBox,darkOrangeColor);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody1ZL2Y1, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //1.2.2 side kiri
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, +2.0, +0.0]);  // amount to translate

                            const buffersBody1ZL2Y2 = initBuffers(gl,positionsBox,darkOrangeColor);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody1ZL2Y2, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //1.2.3 side kiri
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, +2.0, +0.0]);  // amount to translate

                            const buffersBody1ZL2Y3 = initBuffers(gl,positionsBox,orangeColor);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody1ZL2Y3, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //1.2.4 side kiri
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, +2.0, +0.0]);  // amount to translate

                            const buffersBody1ZL2Y4 = initBuffers(gl,positionsBox,darkOrangeColor);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody1ZL2Y4, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //1.2.5 side kiri
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, +2.0, +0.0]);  // amount to translate

                            const buffersBody1ZL2Y5 = initBuffers(gl,positionsBox,orangeColor);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody1ZL2Y5, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //1.2.6 side kiri
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, +2.0, +0.0]);  // amount to translate

                            const buffersBody1ZL2Y6 = initBuffers(gl,positionsBox,darkOrangeColor2);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody1ZL2Y6, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //1.2.7 side kiri
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, +2.0, +0.0]);  // amount to translate

                            const buffersBody1ZL2Y7 = initBuffers(gl,positionsBox,darkOrangeColor2);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody1ZL2Y7, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //1.2.8 side kiri
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, +2.0, +0.0]);  // amount to translate

                            const buffersBody1ZL2Y8 = initBuffers(gl,positionsBox,darkOrangeColor2);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody1ZL2Y8, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //1.2.9 side kiri
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, +2.0, +0.0]);  // amount to translate

                            const buffersBody1ZL2Y9 = initBuffers(gl,positionsBox,darkOrangeColor);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody1ZL2Y9, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //1.2.10 side kiri
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, +2.0, +0.0]);  // amount to translate

                            const buffersBody1ZL2Y10 = initBuffers(gl,positionsBox,orangeColor);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody1ZL2Y10, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                //1.1.1 side kiri
                                mat4.translate(modelViewMatrix,     // destination matrix
                                modelViewMatrix,     // matrix to translate
                                [xParent+0.0, -0.0, +2.0]);  // amount to translate

                                const buffersBody1ZL1Y1 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                axisToRotate = [0, 0, 0];; 
                                drawScene(gl, programInfo, buffersBody1ZL1Y1, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                //1.1.2 side kiri
                                mat4.translate(modelViewMatrix,     // destination matrix
                                modelViewMatrix,     // matrix to translate
                                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                                const buffersBody1ZL1Y2 = initBuffers(gl,positionsBox,darkOrangeColor);
                                axisToRotate = [0, 0, 0];; 
                                drawScene(gl, programInfo, buffersBody1ZL1Y2, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                //1.1.3 side kiri
                                mat4.translate(modelViewMatrix,     // destination matrix
                                modelViewMatrix,     // matrix to translate
                                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                                const buffersBody1ZL1Y3 = initBuffers(gl,positionsBox,orangeColor);
                                axisToRotate = [0, 0, 0];; 
                                drawScene(gl, programInfo, buffersBody1ZL1Y3, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                //1.1.4 side kiri
                                mat4.translate(modelViewMatrix,     // destination matrix
                                modelViewMatrix,     // matrix to translate
                                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                                const buffersBody1ZL1Y4 = initBuffers(gl,positionsBox,orangeColor);
                                axisToRotate = [0, 0, 0];; 
                                drawScene(gl, programInfo, buffersBody1ZL1Y4, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                //1.1.5 side kiri
                                mat4.translate(modelViewMatrix,     // destination matrix
                                modelViewMatrix,     // matrix to translate
                                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                                const buffersBody1ZL1Y5 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                axisToRotate = [0, 0, 0];; 
                                drawScene(gl, programInfo, buffersBody1ZL1Y5, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                //1.1.6 side kiri
                                mat4.translate(modelViewMatrix,     // destination matrix
                                modelViewMatrix,     // matrix to translate
                                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                                const buffersBody1ZL1Y6 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                axisToRotate = [0, 0, 0];; 
                                drawScene(gl, programInfo, buffersBody1ZL1Y6, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                //1.1.7 side kiri
                                mat4.translate(modelViewMatrix,     // destination matrix
                                modelViewMatrix,     // matrix to translate
                                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                                const buffersBody1ZL1Y7 = initBuffers(gl,positionsBox,darkOrangeColor);
                                axisToRotate = [0, 0, 0];; 
                                drawScene(gl, programInfo, buffersBody1ZL1Y7, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                //1.1.8 side kiri
                                mat4.translate(modelViewMatrix,     // destination matrix
                                modelViewMatrix,     // matrix to translate
                                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                                const buffersBody1ZL1Y8 = initBuffers(gl,positionsBox,darkOrangeColor);
                                axisToRotate = [0, 0, 0];; 
                                drawScene(gl, programInfo, buffersBody1ZL1Y8, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                //1.1.9 side kiri
                                mat4.translate(modelViewMatrix,     // destination matrix
                                modelViewMatrix,     // matrix to translate
                                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                                const buffersBody1ZL1Y9 = initBuffers(gl,positionsBox,orangeColor);
                                axisToRotate = [0, 0, 0];; 
                                drawScene(gl, programInfo, buffersBody1ZL1Y9, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                //1.1.10 side kiri
                                mat4.translate(modelViewMatrix,     // destination matrix
                                modelViewMatrix,     // matrix to translate
                                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                                const buffersBody1ZL1Y10 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                axisToRotate = [0, 0, 0];; 
                                drawScene(gl, programInfo, buffersBody1ZL1Y10, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                    //1.0.1 side kiri
                                    mat4.translate(modelViewMatrix,     // destination matrix
                                    modelViewMatrix,     // matrix to translate
                                    [xParent+0.0, -0.0, +2.0]);  // amount to translate

                                    const buffersBody1ZL0Y1 = initBuffers(gl,positionsBox,darkOrangeColor);
                                    axisToRotate = [0, 0, 0];; 
                                    drawScene(gl, programInfo, buffersBody1ZL0Y1, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                    //1.0.2 side kiri
                                    mat4.translate(modelViewMatrix,     // destination matrix
                                    modelViewMatrix,     // matrix to translate
                                    [xParent+0.0, +2.0, +0.0]);  // amount to translate

                                    const buffersBody1ZL0Y2 = initBuffers(gl,positionsBox,orangeColor);
                                    axisToRotate = [0, 0, 0];; 
                                    drawScene(gl, programInfo, buffersBody1ZL0Y2, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                    //1.0.3 side kiri
                                    mat4.translate(modelViewMatrix,     // destination matrix
                                    modelViewMatrix,     // matrix to translate
                                    [xParent+0.0, +2.0, +0.0]);  // amount to translate

                                    const buffersBody1ZL0Y3 = initBuffers(gl,positionsBox,darkOrangeColor);
                                    axisToRotate = [0, 0, 0];; 
                                    drawScene(gl, programInfo, buffersBody1ZL0Y3, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                    //1.0.4 side kiri
                                    mat4.translate(modelViewMatrix,     // destination matrix
                                    modelViewMatrix,     // matrix to translate
                                    [xParent+0.0, +2.0, +0.0]);  // amount to translate

                                    const buffersBody1ZL0Y4 = initBuffers(gl,positionsBox,darkOrangeColor);
                                    axisToRotate = [0, 0, 0];; 
                                    drawScene(gl, programInfo, buffersBody1ZL0Y4, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                    //1.0.5 side kiri
                                    mat4.translate(modelViewMatrix,     // destination matrix
                                    modelViewMatrix,     // matrix to translate
                                    [xParent+0.0, +2.0, +0.0]);  // amount to translate

                                    const buffersBody1ZL0Y5 = initBuffers(gl,positionsBox,darkOrangeColor);
                                    axisToRotate = [0, 0, 0];; 
                                    drawScene(gl, programInfo, buffersBody1ZL0Y5, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                    //1.0.6 side kiri
                                    mat4.translate(modelViewMatrix,     // destination matrix
                                    modelViewMatrix,     // matrix to translate
                                    [xParent+0.0, +2.0, +0.0]);  // amount to translate

                                    const buffersBody1ZL0Y6 = initBuffers(gl,positionsBox,darkOrangeColor);
                                    axisToRotate = [0, 0, 0];; 
                                    drawScene(gl, programInfo, buffersBody1ZL0Y6, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                    //1.0.7 side kiri
                                    mat4.translate(modelViewMatrix,     // destination matrix
                                    modelViewMatrix,     // matrix to translate
                                    [xParent+0.0, +2.0, +0.0]);  // amount to translate

                                    const buffersBody1ZL0Y7 = initBuffers(gl,positionsBox,darkOrangeColor);
                                    axisToRotate = [0, 0, 0];; 
                                    drawScene(gl, programInfo, buffersBody1ZL0Y7, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                    //1.0.8 side kiri
                                    mat4.translate(modelViewMatrix,     // destination matrix
                                    modelViewMatrix,     // matrix to translate
                                    [xParent+0.0, +2.0, +0.0]);  // amount to translate

                                    const buffersBody1ZL0Y8 = initBuffers(gl,positionsBox,orangeColor);
                                    axisToRotate = [0, 0, 0];; 
                                    drawScene(gl, programInfo, buffersBody1ZL0Y8, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                    //1.0.9 side kiri
                                    mat4.translate(modelViewMatrix,     // destination matrix
                                    modelViewMatrix,     // matrix to translate
                                    [xParent+0.0, +2.0, +0.0]);  // amount to translate

                                    const buffersBody1ZL0Y9 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                    axisToRotate = [0, 0, 0];; 
                                    drawScene(gl, programInfo, buffersBody1ZL0Y9, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                    //1.0.10 side kiri
                                    mat4.translate(modelViewMatrix,     // destination matrix
                                    modelViewMatrix,     // matrix to translate
                                    [xParent+0.0, +2.0, +0.0]);  // amount to translate

                                    const buffersBody1ZL0Y10 = initBuffers(gl,positionsBox,darkOrangeColor);
                                    axisToRotate = [0, 0, 0];; 
                                    drawScene(gl, programInfo, buffersBody1ZL0Y10, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

    //1 side kanan
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xParent-2.0, +0.0, -0.0]);  // amount to translate

    const buffersBody1ZR = initBuffers(gl,positionsBox,blackColor);
    axisToRotate = [0, 0, 0];; 
    drawScene(gl, programInfo, buffersBody1ZR, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        // top body
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent+0.0, +0.0, -0.0]);  // amount to translate

        const buffersBody1Top1 = initBuffers(gl,positionsBox,whiteColor);
        axisToRotate = [0, 0, 0];; 
        drawScene(gl, programInfo, buffersBody1Top1, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //1.1 side top
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent+0.0, +0.0, -2.0]);  // amount to translate

        const buffersBody1ZR1 = initBuffers(gl,positionsBox,whiteColor);
        axisToRotate = [0, 0, 0];; 
        drawScene(gl, programInfo, buffersBody1ZR1, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //1.2 side top
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, +0.0, -2.0]);  // amount to translate

            const buffersBody1ZR2 = initBuffers(gl,positionsBox,whiteColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody1ZR2, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //1.3 side top
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, +0.0, -2.0]);  // amount to translate

            const buffersBody1ZR3 = initBuffers(gl,positionsBox,whiteColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody1ZR3, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //1.4 side top
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, +0.0, -2.0]);  // amount to translate

            const buffersBody1ZR4 = initBuffers(gl,positionsBox,whiteColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody1ZR4, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //1.5 side kanan
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, +0.0, -2.0]);  // amount to translate

            const buffersBody1ZR5 = initBuffers(gl,positionsBox,whiteColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody1ZR5, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //1.6 side kanan
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, +0.0, -2.0]);  // amount to translate

            const buffersBody1ZR6 = initBuffers(gl,positionsBox,darkOrangeColor2);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody1ZR6, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //1.6.1 side kanan
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                const buffersBody1ZR6Y1 = initBuffers(gl,positionsBox,darkOrangeColor2);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody1ZR6Y1, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //1.6.2 side kanan
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                const buffersBody1ZR6Y2 = initBuffers(gl,positionsBox,darkOrangeColor2);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody1ZR6Y2, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //1.6.3 side kanan
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                const buffersBody1ZR6Y3 = initBuffers(gl,positionsBox,darkOrangeColor2);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody1ZR6Y3, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //1.6.4 side kanan
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                const buffersBody1ZR6Y4 = initBuffers(gl,positionsBox,darkOrangeColor2);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody1ZR6Y4, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //1.6.5 side kanan
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                const buffersBody1ZR6Y5 = initBuffers(gl,positionsBox,darkOrangeColor2);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody1ZR6Y5, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //1.6.6 side kanan
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                const buffersBody1ZR6Y6 = initBuffers(gl,positionsBox,darkOrangeColor2);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody1ZR6Y6, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //1.6.7 side kanan
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                const buffersBody1ZR6Y7 = initBuffers(gl,positionsBox,darkOrangeColor);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody1ZR6Y7, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //1.6.8 side kanan
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                const buffersBody1ZR6Y8 = initBuffers(gl,positionsBox,darkOrangeColor2);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody1ZR6Y8, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //1.6.9 side kanan
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                const buffersBody1ZR6Y9 = initBuffers(gl,positionsBox,darkOrangeColor);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody1ZR6Y9, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //1.6.10 side kanan
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                const buffersBody1ZR6Y10 = initBuffers(gl,positionsBox,darkOrangeColor);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody1ZR6Y10, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //1 back side body
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent-2.0, +0.0, +0.0]);  // amount to translate

                    const buffersBody1BS = initBuffers(gl,positionsBox,darkOrangeColor2);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody1BS, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //2 back side body
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent-2.0, +0.0, +0.0]);  // amount to translate

                    const buffersBody2BS = initBuffers(gl,positionsBox,darkOrangeColor);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody2BS, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //3 back side body
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent-2.0, +0.0, +0.0]);  // amount to translate

                    const buffersBody3BS = initBuffers(gl,positionsBox,darkOrangeColor);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody3BS, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //3.1 back side body
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, +2.0, +0.0]);  // amount to translate

                        const buffersBody3BS1 = initBuffers(gl,positionsBox,darkOrangeColor);
                        axisToRotate = [0, 0, 0];; 
                        drawScene(gl, programInfo, buffersBody3BS1, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //3.2 back side body
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, +2.0, +0.0]);  // amount to translate

                        const buffersBody3BS2 = initBuffers(gl,positionsBox,darkOrangeColor);
                        axisToRotate = [0, 0, 0];; 
                        drawScene(gl, programInfo, buffersBody3BS2, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //3.3 back side body
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, +2.0, +0.0]);  // amount to translate

                        const buffersBody3BS3 = initBuffers(gl,positionsBox,darkOrangeColor2);
                        axisToRotate = [0, 0, 0];; 
                        drawScene(gl, programInfo, buffersBody3BS3, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //3.4 back side body
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, +2.0, +0.0]);  // amount to translate

                        const buffersBody3BS4 = initBuffers(gl,positionsBox,darkOrangeColor2);
                        axisToRotate = [0, 0, 0];; 
                        drawScene(gl, programInfo, buffersBody3BS4, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //3.5 back side body
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, +2.0, +0.0]);  // amount to translate

                        const buffersBody3BS5 = initBuffers(gl,positionsBox,darkOrangeColor2);
                        axisToRotate = [0, 0, 0];; 
                        drawScene(gl, programInfo, buffersBody3BS5, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //3.6 back side body
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, +2.0, +0.0]);  // amount to translate

                        const buffersBody3BS6 = initBuffers(gl,positionsBox,darkOrangeColor2);
                        axisToRotate = [0, 0, 0];; 
                        drawScene(gl, programInfo, buffersBody3BS6, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //3.7 back side body
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, +2.0, +0.0]);  // amount to translate

                        const buffersBody3BS7 = initBuffers(gl,positionsBox,darkOrangeColor);
                        axisToRotate = [0, 0, 0];; 
                        drawScene(gl, programInfo, buffersBody3BS7, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //3.8 back side body
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, +2.0, +0.0]);  // amount to translate

                        const buffersBody3BS8 = initBuffers(gl,positionsBox,darkOrangeColor);
                        axisToRotate = [0, 0, 0];; 
                        drawScene(gl, programInfo, buffersBody3BS8, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //3.9 back side body
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, +2.0, +0.0]);  // amount to translate

                        const buffersBody3BS9 = initBuffers(gl,positionsBox,darkOrangeColor);
                        axisToRotate = [0, 0, 0];; 
                        drawScene(gl, programInfo, buffersBody3BS9, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //3.10 back side body
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, +2.0, +0.0]);  // amount to translate

                        const buffersBody3BS10 = initBuffers(gl,positionsBox,darkOrangeColor2);
                        axisToRotate = [0, 0, 0];; 
                        drawScene(gl, programInfo, buffersBody3BS10, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //2.1 back side body
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+2.0, +0.0, -0.0]);  // amount to translate

                            const buffersBody2BS1 = initBuffers(gl,positionsBox,darkOrangeColor);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody2BS1, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //2.2 back side body
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, -2.0, -0.0]);  // amount to translate

                            const buffersBody2BS2 = initBuffers(gl,positionsBox,darkOrangeColor);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody2BS2, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //2.3 back side body
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, -2.0, -0.0]);  // amount to translate

                            const buffersBody2BS3 = initBuffers(gl,positionsBox,darkOrangeColor);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody2BS3, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //2.4 back side body
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, -2.0, -0.0]);  // amount to translate

                            const buffersBody2BS4 = initBuffers(gl,positionsBox,darkOrangeColor2);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody2BS4, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //2.5 back side body
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, -2.0, -0.0]);  // amount to translate

                            const buffersBody2BS5 = initBuffers(gl,positionsBox,darkOrangeColor2);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody2BS5, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //2.6 back side body
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, -2.0, -0.0]);  // amount to translate

                            const buffersBody2BS6 = initBuffers(gl,positionsBox,darkOrangeColor2);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody2BS6, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //2.7 back side body
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, -2.0, -0.0]);  // amount to translate

                            const buffersBody2BS7 = initBuffers(gl,positionsBox,darkOrangeColor2);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody2BS7, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //2.8 back side body
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, -2.0, -0.0]);  // amount to translate

                            const buffersBody2BS8 = initBuffers(gl,positionsBox,darkOrangeColor2);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody2BS8, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //2.9 back side body
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, -2.0, -0.0]);  // amount to translate

                            const buffersBody2BS9 = initBuffers(gl,positionsBox,darkOrangeColor2);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody2BS9, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //2.10 back side body
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, -2.0, -0.0]);  // amount to translate

                            const buffersBody2BS10 = initBuffers(gl,positionsBox,darkOrangeColor2);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody2BS10, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                //1.1 back side body
                                mat4.translate(modelViewMatrix,     // destination matrix
                                modelViewMatrix,     // matrix to translate
                                [xParent+2.0, +0.0, -0.0]);  // amount to translate

                                const buffersBody1BS1 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                axisToRotate = [0, 0, 0];; 
                                drawScene(gl, programInfo, buffersBody1BS1, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                //1.2 back side body
                                mat4.translate(modelViewMatrix,     // destination matrix
                                modelViewMatrix,     // matrix to translate
                                [xParent+0.0, +2.0, -0.0]);  // amount to translate

                                const buffersBody1BS2 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                axisToRotate = [0, 0, 0];; 
                                drawScene(gl, programInfo, buffersBody1BS2, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                //1.3 back side body
                                mat4.translate(modelViewMatrix,     // destination matrix
                                modelViewMatrix,     // matrix to translate
                                [xParent+0.0, +2.0, -0.0]);  // amount to translate

                                const buffersBody1BS3 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                axisToRotate = [0, 0, 0];; 
                                drawScene(gl, programInfo, buffersBody1BS3, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                //1.4 back side body
                                mat4.translate(modelViewMatrix,     // destination matrix
                                modelViewMatrix,     // matrix to translate
                                [xParent+0.0, +2.0, -0.0]);  // amount to translate

                                const buffersBody1BS4 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                axisToRotate = [0, 0, 0];; 
                                drawScene(gl, programInfo, buffersBody1BS4, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                //1.5 back side body
                                mat4.translate(modelViewMatrix,     // destination matrix
                                modelViewMatrix,     // matrix to translate
                                [xParent+0.0, +2.0, -0.0]);  // amount to translate

                                const buffersBody1BS5 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                axisToRotate = [0, 0, 0];; 
                                drawScene(gl, programInfo, buffersBody1BS5, cubeRotation2, axisToRotate, modelViewMatrix, projectionMatrix);
                                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                //1.6 back side body
                                mat4.translate(modelViewMatrix,     // destination matrix
                                modelViewMatrix,     // matrix to translate
                                [xParent+0.0, +2.0, -0.0]);  // amount to translate

                                const buffersBody1BS6 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                axisToRotate = [0, 0, 0];; 
                                drawScene(gl, programInfo, buffersBody1BS6, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                //1.7 back side body
                                mat4.translate(modelViewMatrix,     // destination matrix
                                modelViewMatrix,     // matrix to translate
                                [xParent+0.0, +2.0, -0.0]);  // amount to translate

                                const buffersBody1BS7 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                axisToRotate = [0, 0, 0];; 
                                drawScene(gl, programInfo, buffersBody1BS7, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                //1.8 back side body
                                mat4.translate(modelViewMatrix,     // destination matrix
                                modelViewMatrix,     // matrix to translate
                                [xParent+0.0, +2.0, -0.0]);  // amount to translate

                                const buffersBody1BS8 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                axisToRotate = [0, 0, 0];; 
                                drawScene(gl, programInfo, buffersBody1BS8, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                //1.9 back side body
                                mat4.translate(modelViewMatrix,     // destination matrix
                                modelViewMatrix,     // matrix to translate
                                [xParent+0.0, +2.0, -0.0]);  // amount to translate

                                const buffersBody1BS9 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                axisToRotate = [0, 0, 0];; 
                                drawScene(gl, programInfo, buffersBody1BS9, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                //1.10 back side body
                                mat4.translate(modelViewMatrix,     // destination matrix
                                modelViewMatrix,     // matrix to translate
                                [xParent+0.0, +2.0, -0.0]);  // amount to translate

                                const buffersBody1BS10 = initBuffers(gl,positionsBox,darkOrangeColor);
                                axisToRotate = [0, 0, 0];; 
                                drawScene(gl, programInfo, buffersBody1BS10, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //1 top side body
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xParent+0.0, -0.0, +2.0]);  // amount to translate

    const buffersBody1Top = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0];; 
    drawScene(gl, programInfo, buffersBody1Top, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //2 top side body
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xParent+0.0, -0.0, +2.0]);  // amount to translate

    const buffersBody2Top = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0];; 
    drawScene(gl, programInfo, buffersBody2Top, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //3 top side body
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xParent+0.0, -0.0, +2.0]);  // amount to translate

    const buffersBody3Top = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0];; 
    drawScene(gl, programInfo, buffersBody3Top, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //4 top side body
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xParent+0.0, -0.0, +2.0]);  // amount to translate

    const buffersBody4Top = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0];; 
    drawScene(gl, programInfo, buffersBody4Top, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //5 top side body
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xParent+0.0, -0.0, +2.0]);  // amount to translate

    const buffersBody5Top = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0];; 
    drawScene(gl, programInfo, buffersBody5Top, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //6 top side body
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xParent+0.0, -0.0, +2.0]);  // amount to translate

    const buffersBody6Top = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0];; 
    drawScene(gl, programInfo, buffersBody6Top, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //6.1 top side body
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent-2.0, +0.0, +0.0]);  // amount to translate

        const buffersBody6Top1 = initBuffers(gl,positionsBox,whiteColor);
        axisToRotate = [0, 0, 0];; 
        drawScene(gl, programInfo, buffersBody6Top1, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //6.2 top side body
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent+0.0, +0.0, -2.0]);  // amount to translate

        const buffersBody6Top2 = initBuffers(gl,positionsBox,whiteColor);
        axisToRotate = [0, 0, 0];; 
        drawScene(gl, programInfo, buffersBody6Top2, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //6.3 top side body
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent+0.0, +0.0, -2.0]);  // amount to translate

        const buffersBody6Top3 = initBuffers(gl,positionsBox,whiteColor);
        axisToRotate = [0, 0, 0];; 
        drawScene(gl, programInfo, buffersBody6Top3, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //6.4 top side body
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent+0.0, +0.0, -2.0]);  // amount to translate

        const buffersBody6Top4 = initBuffers(gl,positionsBox,whiteColor);
        axisToRotate = [0, 0, 0];; 
        drawScene(gl, programInfo, buffersBody6Top4, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //6.5 top side body
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent+0.0, +0.0, -2.0]);  // amount to translate

        const buffersBody6Top5 = initBuffers(gl,positionsBox,whiteColor);
        axisToRotate = [0, 0, 0];; 
        drawScene(gl, programInfo, buffersBody6Top5, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //6.6 top side body
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent+0.0, +0.0, -2.0]);  // amount to translate

        const buffersBody6Top6 = initBuffers(gl,positionsBox,whiteColor);
        axisToRotate = [0, 0, 0];; 
        drawScene(gl, programInfo, buffersBody6Top6, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //5.1 top side body
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent-2.0, +0.0, -0.0]);  // amount to translate

            const buffersBody5Top1 = initBuffers(gl,positionsBox,whiteColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody5Top1, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //5.2 top side body
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, -0.0, +2.0]);  // amount to translate

            const buffersBody5Top2 = initBuffers(gl,positionsBox,whiteColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody5Top2, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //5.3 top side body
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, -0.0, +2.0]);  // amount to translate

            const buffersBody5Top3 = initBuffers(gl,positionsBox,whiteColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody5Top3, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //5.4 top side body
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, -0.0, +2.0]);  // amount to translate

            const buffersBody5Top4 = initBuffers(gl,positionsBox,whiteColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody5Top4, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //5.5 top side body
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, -0.0, +2.0]);  // amount to translate

            const buffersBody5Top5 = initBuffers(gl,positionsBox,whiteColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody5Top5, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //5.6 top side body
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+0.0, -0.0, +2.0]);  // amount to translate

            const buffersBody5Top6 = initBuffers(gl,positionsBox,whiteColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody5Top6, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //4.1 top side body
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent-2.0, +0.0, +0.0]);  // amount to translate

                const buffersBody4Top1 = initBuffers(gl,positionsBox,darkOrangeColor);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody4Top1, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //4.2 top side body
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, +0.0, -2.0]);  // amount to translate

                const buffersBody4Top2 = initBuffers(gl,positionsBox,darkOrangeColor2);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody4Top2, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //4.3 top side body
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, +0.0, -2.0]);  // amount to translate

                const buffersBody4Top3 = initBuffers(gl,positionsBox,darkOrangeColor2);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody4Top3, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //4.4 top side body
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, +0.0, -2.0]);  // amount to translate

                const buffersBody4Top4 = initBuffers(gl,positionsBox,darkOrangeColor2);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody4Top4, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //4.5 top side body
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, +0.0, -2.0]);  // amount to translate

                const buffersBody4Top5 = initBuffers(gl,positionsBox,darkOrangeColor2);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody4Top5, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //4.6 top side body
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, +0.0, -2.0]);  // amount to translate

                const buffersBody4Top6 = initBuffers(gl,positionsBox,darkOrangeColor2);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody4Top6, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //4.7 top side body
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, +0.0, -2.0]);  // amount to translate

                const buffersBody4Top7 = initBuffers(gl,positionsBox,darkOrangeColor);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody4Top7, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //7 additional side kiri...?
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, -2.0, -0.0]);  // amount to translate

                    const buffersBody7Top = initBuffers(gl,positionsBox,darkOrangeColor);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody7Top, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //7.1 additional side kiri...?
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, -2.0, -0.0]);  // amount to translate

                    const buffersBody7Top1 = initBuffers(gl,positionsBox,darkOrangeColor);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody7Top1, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //7.2 additional side kiri...?
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, -2.0, -0.0]);  // amount to translate

                    const buffersBody7Top2 = initBuffers(gl,positionsBox,darkOrangeColor);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody7Top2, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //7.3 additional side kiri...?
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, -2.0, -0.0]);  // amount to translate

                    const buffersBody7Top3 = initBuffers(gl,positionsBox,darkOrangeColor);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody7Top3, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //7.4 additional side kiri...?
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, -2.0, -0.0]);  // amount to translate

                    const buffersBody7Top4 = initBuffers(gl,positionsBox,darkOrangeColor);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody7Top4, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //7.5 additional side kiri...?
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, -2.0, -0.0]);  // amount to translate

                    const buffersBody7Top5 = initBuffers(gl,positionsBox,darkOrangeColor);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody7Top5, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //7.6 additional side kiri...?
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, -2.0, -0.0]);  // amount to translate

                    const buffersBody7Top6 = initBuffers(gl,positionsBox,darkOrangeColor);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody7Top6, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //7.7 additional side kiri...?
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, -2.0, -0.0]);  // amount to translate

                    const buffersBody7Top7 = initBuffers(gl,positionsBox,darkOrangeColor);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody7Top7, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //7.8 additional side kiri...?
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, -2.0, -0.0]);  // amount to translate

                    const buffersBody7Top8 = initBuffers(gl,positionsBox,darkOrangeColor);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody7Top8, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //7.9 additional side kiri...?
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, -2.0, -0.0]);  // amount to translate

                    const buffersBody7Top9 = initBuffers(gl,positionsBox,darkOrangeColor);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody7Top9, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //1 kanan side body
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xParent-0.0, -0.0, +2.0]);  // amount to translate

    const buffersBody1TS = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0];; 
    drawScene(gl, programInfo, buffersBody1TS, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //2 kanan side body
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xParent-0.0, +2.0, -0.0]);  // amount to translate

    const buffersBody2TS = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0];; 
    drawScene(gl, programInfo, buffersBody2TS, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //3 kanan side body
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xParent-0.0, +2.0, -0.0]);  // amount to translate

    const buffersBody3TS = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0];; 
    drawScene(gl, programInfo, buffersBody3TS, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //4 kanan side body
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xParent-0.0, +2.0, -0.0]);  // amount to translate

    const buffersBody4TS = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0];; 
    drawScene(gl, programInfo, buffersBody4TS, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //5 kanan side body
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xParent-0.0, +2.0, -0.0]);  // amount to translate

    const buffersBody5TS = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0];; 
    drawScene(gl, programInfo, buffersBody5TS, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //6 kanan side body
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xParent-0.0, +2.0, -0.0]);  // amount to translate

    const buffersBody6TS = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0];; 
    drawScene(gl, programInfo, buffersBody6TS, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //7 kanan side body
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xParent-0.0, +2.0, -0.0]);  // amount to translate

    const buffersBody7TS = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0];; 
    drawScene(gl, programInfo, buffersBody7TS, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //8 kanan side body
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xParent-0.0, +2.0, -0.0]);  // amount to translate

    const buffersBody8TS = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0];; 
    drawScene(gl, programInfo, buffersBody8TS, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //9 kanan side body
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xParent-0.0, +2.0, -0.0]);  // amount to translate

    const buffersBody9TS = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0];; 
    drawScene(gl, programInfo, buffersBody9TS, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //10 kanan side body
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xParent-0.0, +2.0, -0.0]);  // amount to translate

    const buffersBody10TS = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0];; 
    drawScene(gl, programInfo, buffersBody10TS, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //10.1 kanan side body
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent-0.0, +0.0, +2.0]);  // amount to translate

        const buffersBody10TS1 = initBuffers(gl,positionsBox,darkOrangeColor2);
        axisToRotate = [0, 0, 0];; 
        drawScene(gl, programInfo, buffersBody10TS1, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //10.2 kanan side body
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent-0.0, +0.0, +2.0]);  // amount to translate

        const buffersBody10TS2 = initBuffers(gl,positionsBox,orangeColor);
        axisToRotate = [0, 0, 0];; 
        drawScene(gl, programInfo, buffersBody10TS2, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //10.3 kanan side body
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent-0.0, +0.0, +2.0]);  // amount to translate

        const buffersBody10TS3 = initBuffers(gl,positionsBox,darkOrangeColor2);
        axisToRotate = [0, 0, 0];; 
        drawScene(gl, programInfo, buffersBody10TS3, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //10.4 kanan side body
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent-0.0, +0.0, +2.0]);  // amount to translate

        const buffersBody10TS4 = initBuffers(gl,positionsBox,darkOrangeColor);
        axisToRotate = [0, 0, 0];; 
        drawScene(gl, programInfo, buffersBody10TS4, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //10.5 kanan side body
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent-0.0, +0.0, +2.0]);  // amount to translate

        const buffersBody10TS5 = initBuffers(gl,positionsBox,darkOrangeColor);
        axisToRotate = [0, 0, 0];; 
        drawScene(gl, programInfo, buffersBody10TS5, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //9.5 kanan side body
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent-0.0, -2.0, +0.0]);  // amount to translate

            const buffersBody9TS5 = initBuffers(gl,positionsBox,orangeColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody9TS5, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //9.4 kanan side body
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent-0.0, +0.0, -2.0]);  // amount to translate

            const buffersBody9TS4 = initBuffers(gl,positionsBox,darkOrangeColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody9TS4, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //9.3 kanan side body
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent-0.0, +0.0, -2.0]);  // amount to translate

            const buffersBody9TS3 = initBuffers(gl,positionsBox,darkOrangeColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody9TS3, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //9.2 kanan side body
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent-0.0, +0.0, -2.0]);  // amount to translate

            const buffersBody9TS2 = initBuffers(gl,positionsBox,darkOrangeColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody9TS2, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //9.1 kanan side body
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent-0.0, +0.0, -2.0]);  // amount to translate

            const buffersBody9TS1 = initBuffers(gl,positionsBox,darkOrangeColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody9TS1, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //8.1 kanan side body
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                const buffersBody8TS1 = initBuffers(gl,positionsBox,darkerOrangeColor);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody8TS1, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //8.2 kanan side body
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, -0.0, +2.0]);  // amount to translate

                const buffersBody8TS2 = initBuffers(gl,positionsBox,darkOrangeColor);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody8TS2, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //8.3 kanan side body
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, -0.0, +2.0]);  // amount to translate

                const buffersBody8TS3 = initBuffers(gl,positionsBox,darkOrangeColor);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody8TS3, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //8.4 kanan side body
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, -0.0, +2.0]);  // amount to translate

                const buffersBody8TS4 = initBuffers(gl,positionsBox,orangeColor);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody8TS4, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //8.5 kanan side body
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+0.0, -0.0, +2.0]);  // amount to translate

                const buffersBody8TS5 = initBuffers(gl,positionsBox,orangeColor);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody8TS5, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //7.5 kanan side body
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent+0.0, -2.0, +0.0]);  // amount to translate
                    
                    const buffersBody7TS5 = initBuffers(gl,positionsBox,darkOrangeColor);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody7TS5, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //7.4 kanan side body
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent-0.0, +0.0, -2.0]);  // amount to translate
                    
                    const buffersBody7TS4 = initBuffers(gl,positionsBox,darkOrangeColor);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody7TS4, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //7.3 kanan side body
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent-0.0, +0.0, -2.0]);  // amount to translate
                    
                    const buffersBody7TS3 = initBuffers(gl,positionsBox,darkOrangeColor);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody7TS3, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //7.2 kanan side body
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent-0.0, +0.0, -2.0]);  // amount to translate
                    
                    const buffersBody7TS2 = initBuffers(gl,positionsBox,darkerOrangeColor);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody7TS2, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                    //7.1 kanan side body
                    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xParent-0.0, +0.0, -2.0]);  // amount to translate
                    
                    const buffersBody7TS1 = initBuffers(gl,positionsBox,darkerOrangeColor);
                    axisToRotate = [0, 0, 0];; 
                    drawScene(gl, programInfo, buffersBody7TS1, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //6.1 kanan side body
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, -2.0, +0.0]);  // amount to translate

                        const buffersBody6TS1 = initBuffers(gl,positionsBox,orangeColor);
                        axisToRotate = [0, 0, 0];; 
                        drawScene(gl, programInfo, buffersBody6TS1, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //6.2 kanan side body
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, -0.0, +2.0]);  // amount to translate

                        const buffersBody6TS2 = initBuffers(gl,positionsBox,darkOrangeColor);
                        axisToRotate = [0, 0, 0];; 
                        drawScene(gl, programInfo, buffersBody6TS2, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //6.3 kanan side body
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, -0.0, +2.0]);  // amount to translate

                        const buffersBody6TS3 = initBuffers(gl,positionsBox,orangeColor);
                        axisToRotate = [0, 0, 0];; 
                        drawScene(gl, programInfo, buffersBody6TS3, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //6.4 kanan side body
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, -0.0, +2.0]);  // amount to translate

                        const buffersBody6TS4 = initBuffers(gl,positionsBox,darkOrangeColor);
                        axisToRotate = [0, 0, 0];; 
                        drawScene(gl, programInfo, buffersBody6TS4, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                        //6.5 kanan side body
                        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xParent+0.0, -0.0, +2.0]);  // amount to translate

                        const buffersBody6TS5 = initBuffers(gl,positionsBox,orangeColor);
                        axisToRotate = [0, 0, 0];; 
                        drawScene(gl, programInfo, buffersBody6TS5, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //5.5 kanan side body
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent+0.0, -2.0, +0.0]);  // amount to translate
                            
                            const buffersBody5TS5 = initBuffers(gl,positionsBox,orangeColor);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody5TS5, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //5.4 kanan side body
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent-0.0, +0.0, -2.0]);  // amount to translate
                            
                            const buffersBody5TS4 = initBuffers(gl,positionsBox,orangeColor);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody5TS4, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //5.3 kanan side body
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent-0.0, +0.0, -2.0]);  // amount to translate
                            
                            const buffersBody5TS3 = initBuffers(gl,positionsBox,orangeColor);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody5TS3, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //5.2 kanan side body
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent-0.0, +0.0, -2.0]);  // amount to translate
                            
                            const buffersBody5TS2 = initBuffers(gl,positionsBox,orangeColor);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody5TS2, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                            //5.1 kanan side body
                            mat4.translate(modelViewMatrix,     // destination matrix
                            modelViewMatrix,     // matrix to translate
                            [xParent-0.0, +0.0, -2.0]);  // amount to translate
                            
                            const buffersBody5TS1 = initBuffers(gl,positionsBox,orangeColor);
                            axisToRotate = [0, 0, 0];; 
                            drawScene(gl, programInfo, buffersBody5TS1, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                //4.1 kanan side body
                                mat4.translate(modelViewMatrix,     // destination matrix
                                modelViewMatrix,     // matrix to translate
                                [xParent+0.0, -2.0, +0.0]);  // amount to translate

                                const buffersBody4TS1 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                axisToRotate = [0, 0, 0];; 
                                drawScene(gl, programInfo, buffersBody4TS1, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                //4.2 kanan side body
                                mat4.translate(modelViewMatrix,     // destination matrix
                                modelViewMatrix,     // matrix to translate
                                [xParent+0.0, -0.0, +2.0]);  // amount to translate

                                const buffersBody4TS2 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                axisToRotate = [0, 0, 0];; 
                                drawScene(gl, programInfo, buffersBody4TS2, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                //4.3 kanan side body
                                mat4.translate(modelViewMatrix,     // destination matrix
                                modelViewMatrix,     // matrix to translate
                                [xParent+0.0, -0.0, +2.0]);  // amount to translate

                                const buffersBody4TS3 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                axisToRotate = [0, 0, 0];; 
                                drawScene(gl, programInfo, buffersBody4TS3, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                //4.4 kanan side body
                                mat4.translate(modelViewMatrix,     // destination matrix
                                modelViewMatrix,     // matrix to translate
                                [xParent+0.0, -0.0, +2.0]);  // amount to translate

                                const buffersBody4TS4 = initBuffers(gl,positionsBox,orangeColor);
                                axisToRotate = [0, 0, 0];; 
                                drawScene(gl, programInfo, buffersBody4TS4, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                //4.5 kanan side body
                                mat4.translate(modelViewMatrix,     // destination matrix
                                modelViewMatrix,     // matrix to translate
                                [xParent+0.0, -0.0, +2.0]);  // amount to translate

                                const buffersBody4TS5 = initBuffers(gl,positionsBox,orangeColor);
                                axisToRotate = [0, 0, 0];; 
                                drawScene(gl, programInfo, buffersBody4TS5, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                    //3.5 kanan side body
                                    mat4.translate(modelViewMatrix,     // destination matrix
                                    modelViewMatrix,     // matrix to translate
                                    [xParent+0.0, -2.0, +0.0]);  // amount to translate
                                    
                                    const buffersBody3TS5 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                    axisToRotate = [0, 0, 0];; 
                                    drawScene(gl, programInfo, buffersBody3TS5, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                    //3.4 kanan side body
                                    mat4.translate(modelViewMatrix,     // destination matrix
                                    modelViewMatrix,     // matrix to translate
                                    [xParent-0.0, +0.0, -2.0]);  // amount to translate
                                    
                                    const buffersBody3TS4 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                    axisToRotate = [0, 0, 0];; 
                                    drawScene(gl, programInfo, buffersBody3TS4, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                    //3.3 kanan side body
                                    mat4.translate(modelViewMatrix,     // destination matrix
                                    modelViewMatrix,     // matrix to translate
                                    [xParent-0.0, +0.0, -2.0]);  // amount to translate
                                    
                                    const buffersBody3TS3 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                    axisToRotate = [0, 0, 0];; 
                                    drawScene(gl, programInfo, buffersBody3TS3, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                    //3.2 kanan side body
                                    mat4.translate(modelViewMatrix,     // destination matrix
                                    modelViewMatrix,     // matrix to translate
                                    [xParent-0.0, +0.0, -2.0]);  // amount to translate
                                    
                                    const buffersBody3TS2 = initBuffers(gl,positionsBox,orangeColor);
                                    axisToRotate = [0, 0, 0];; 
                                    drawScene(gl, programInfo, buffersBody3TS2, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                    //3.1 kanan side body
                                    mat4.translate(modelViewMatrix,     // destination matrix
                                    modelViewMatrix,     // matrix to translate
                                    [xParent-0.0, +0.0, -2.0]);  // amount to translate
                                    
                                    const buffersBody3TS1 = initBuffers(gl,positionsBox,darkOrangeColor);
                                    axisToRotate = [0, 0, 0];; 
                                    drawScene(gl, programInfo, buffersBody3TS1, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                                    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                        //2.1 kanan side body
                                        mat4.translate(modelViewMatrix,     // destination matrix
                                        modelViewMatrix,     // matrix to translate
                                        [xParent+0.0, -2.0, +0.0]);  // amount to translate

                                        const buffersBody2TS1 = initBuffers(gl,positionsBox,darkerOrangeColor);
                                        axisToRotate = [0, 0, 0];; 
                                        drawScene(gl, programInfo, buffersBody2TS1, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                        //2.2 kanan side body
                                        mat4.translate(modelViewMatrix,     // destination matrix
                                        modelViewMatrix,     // matrix to translate
                                        [xParent+0.0, -0.0, +2.0]);  // amount to translate

                                        const buffersBody2TS2 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                        axisToRotate = [0, 0, 0];; 
                                        drawScene(gl, programInfo, buffersBody2TS2, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                        //2.3 kanan side body
                                        mat4.translate(modelViewMatrix,     // destination matrix
                                        modelViewMatrix,     // matrix to translate
                                        [xParent+0.0, -0.0, +2.0]);  // amount to translate

                                        const buffersBody2TS3 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                        axisToRotate = [0, 0, 0];; 
                                        drawScene(gl, programInfo, buffersBody2TS3, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                        //2.4 kanan side body
                                        mat4.translate(modelViewMatrix,     // destination matrix
                                        modelViewMatrix,     // matrix to translate
                                        [xParent+0.0, -0.0, +2.0]);  // amount to translate

                                        const buffersBody2TS4 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                        axisToRotate = [0, 0, 0];; 
                                        drawScene(gl, programInfo, buffersBody2TS4, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                        //2.5 kanan side body
                                        mat4.translate(modelViewMatrix,     // destination matrix
                                        modelViewMatrix,     // matrix to translate
                                        [xParent+0.0, -0.0, +2.0]);  // amount to translate

                                        const buffersBody2TS5 = initBuffers(gl,positionsBox,darkerOrangeColor);
                                        axisToRotate = [0, 0, 0];; 
                                        drawScene(gl, programInfo, buffersBody2TS5, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                                        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                            //1.5 kanan side body
                                            mat4.translate(modelViewMatrix,     // destination matrix
                                            modelViewMatrix,     // matrix to translate
                                            [xParent+0.0, -2.0, +0.0]);  // amount to translate
                                            
                                            const buffersBody1TS5 = initBuffers(gl,positionsBox,darkerOrangeColor);
                                            axisToRotate = [0, 0, 0];; 
                                            drawScene(gl, programInfo, buffersBody1TS5, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                            //1.4 kanan side body
                                            mat4.translate(modelViewMatrix,     // destination matrix
                                            modelViewMatrix,     // matrix to translate
                                            [xParent-0.0, +0.0, -2.0]);  // amount to translate
                                            
                                            const buffersBody1TS4 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                            axisToRotate = [0, 0, 0];; 
                                            drawScene(gl, programInfo, buffersBody1TS4, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                            //1.3 kanan side body
                                            mat4.translate(modelViewMatrix,     // destination matrix
                                            modelViewMatrix,     // matrix to translate
                                            [xParent-0.0, +0.0, -2.0]);  // amount to translate
                                            
                                            const buffersBody1TS3 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                            axisToRotate = [0, 0, 0];; 
                                            drawScene(gl, programInfo, buffersBody1TS3, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                            //1.2 kanan side body
                                            mat4.translate(modelViewMatrix,     // destination matrix
                                            modelViewMatrix,     // matrix to translate
                                            [xParent-0.0, +0.0, -2.0]);  // amount to translate
                                            
                                            const buffersBody1TS2 = initBuffers(gl,positionsBox,darkOrangeColor2);
                                            axisToRotate = [0, 0, 0];; 
                                            drawScene(gl, programInfo, buffersBody1TS2, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                                            //1.1 kanan side body
                                            mat4.translate(modelViewMatrix,     // destination matrix
                                            modelViewMatrix,     // matrix to translate
                                            [xParent-0.0, +0.0, -2.0]);  // amount to translate
                                            
                                            const buffersBody1TS1 = initBuffers(gl,positionsBox,darkOrangeColor);
                                            axisToRotate = [0, 0, 0];; 
                                            drawScene(gl, programInfo, buffersBody1TS1, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                                            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //1 tail side body
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xParent+2.0, +0.0, -2.0]);  // amount to translate
    
    const buffersBody1TaS = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0];; 
    drawScene(gl, programInfo, buffersBody1TaS, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //2 tail side body
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xParent+0.0, -0.0, +2.0]);  // amount to translate
    
    const buffersBody2TaS = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0];; 
    drawScene(gl, programInfo, buffersBody2TaS, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //3 tail side body
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xParent+0.0, -0.0, +2.0]);  // amount to translate
    
    const buffersBody3TaS = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0];; 
    drawScene(gl, programInfo, buffersBody3TaS, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //4 tail side body
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xParent+0.0, -0.0, +2.0]);  // amount to translate
    
    const buffersBody4TaS = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0];; 
    drawScene(gl, programInfo, buffersBody4TaS, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //5 tail side body
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xParent+0.0, -0.0, +2.0]);  // amount to translate
    
    const buffersBody5TaS = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0];; 
    drawScene(gl, programInfo, buffersBody5TaS, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //6 tail side body
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xParent+0.0, -0.0, +2.0]);  // amount to translate
    
    const buffersBody6TaS = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0];; 
    drawScene(gl, programInfo, buffersBody6TaS, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //6.1 tail side body
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent+2.0, -0.0, -0.0]);  // amount to translate
        
        const buffersBody6TaS1 = initBuffers(gl,positionsBox,whiteColor);
        axisToRotate = [0, 0, 0];; 
        drawScene(gl, programInfo, buffersBody6TaS1, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //6.2 tail side body
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent-0.0, -0.0, -2.0]);  // amount to translate
        
        const buffersBody6TaS2 = initBuffers(gl,positionsBox,whiteColor);
        axisToRotate = [0, 0, 0];; 
        drawScene(gl, programInfo, buffersBody6TaS2, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //6.3 tail side body
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent-0.0, -0.0, -2.0]);  // amount to translate
        
        const buffersBody6TaS3 = initBuffers(gl,positionsBox,whiteColor);
        axisToRotate = [0, 0, 0];; 
        drawScene(gl, programInfo, buffersBody6TaS3, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //6.4 tail side body
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent-0.0, -0.0, -2.0]);  // amount to translate
        
        const buffersBody6TaS4 = initBuffers(gl,positionsBox,whiteColor);
        axisToRotate = [0, 0, 0];; 
        drawScene(gl, programInfo, buffersBody6TaS4, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //6.5 tail side body
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent-0.0, -0.0, -2.0]);  // amount to translate
        
        const buffersBody6TaS5 = initBuffers(gl,positionsBox,whiteColor);
        axisToRotate = [0, 0, 0];; 
        drawScene(gl, programInfo, buffersBody6TaS5, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        //6.6 tail side body
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xParent-0.0, -0.0, -2.0]);  // amount to translate
        
        const buffersBody6TaS6 = initBuffers(gl,positionsBox,whiteColor);
        axisToRotate = [0, 0, 0];; 
        drawScene(gl, programInfo, buffersBody6TaS6, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //5.1 tail side body
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent+2.0, -0.0, +0.0]);  // amount to translate
            
            const buffersBody5TaS1 = initBuffers(gl,positionsBox,whiteColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody5TaS1, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //5.2 tail side body
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent-0.0, -0.0, +2.0]);  // amount to translate
            
            const buffersBody5TaS2 = initBuffers(gl,positionsBox,whiteColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody5TaS2, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //5.3 tail side body
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent-0.0, -0.0, +2.0]);  // amount to translate
            
            const buffersBody5TaS3 = initBuffers(gl,positionsBox,whiteColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody5TaS3, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //5.4 tail side body
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent-0.0, -0.0, +2.0]);  // amount to translate
            
            const buffersBody5TaS4 = initBuffers(gl,positionsBox,whiteColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody5TaS4, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //5.5 tail side body
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent-0.0, -0.0, +2.0]);  // amount to translate
            
            const buffersBody5TaS5 = initBuffers(gl,positionsBox,whiteColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody5TaS5, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            //5.6 tail side body
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xParent-0.0, -0.0, +2.0]);  // amount to translate
            
            const buffersBody5TaS6 = initBuffers(gl,positionsBox,whiteColor);
            axisToRotate = [0, 0, 0];; 
            drawScene(gl, programInfo, buffersBody5TaS6, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //4.1 tail side body
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent+2.0, -0.0, -0.0]);  // amount to translate
                
                const buffersBody4TaS1 = initBuffers(gl,positionsBox,whiteColor);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody4TaS1, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //4.2 tail side body
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent-0.0, -0.0, -2.0]);  // amount to translate
                
                const buffersBody4TaS2 = initBuffers(gl,positionsBox,whiteColor);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody4TaS2, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //4.3 tail side body
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent-0.0, -0.0, -2.0]);  // amount to translate
                
                const buffersBody4TaS3 = initBuffers(gl,positionsBox,whiteColor);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody4TaS3, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //4.4 tail side body
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent-0.0, -0.0, -2.0]);  // amount to translate
                
                const buffersBody4TaS4 = initBuffers(gl,positionsBox,whiteColor);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody4TaS4, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //4.5 tail side body
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent-0.0, -0.0, -2.0]);  // amount to translate
                
                const buffersBody4TaS5 = initBuffers(gl,positionsBox,whiteColor);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody4TaS5, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
                //4.6 tail side body
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xParent-0.0, -0.0, -2.0]);  // amount to translate
                
                const buffersBody4TaS6 = initBuffers(gl,positionsBox,whiteColor);
                axisToRotate = [0, 0, 0];; 
                drawScene(gl, programInfo, buffersBody4TaS6, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
            

    // DRAW FOX Tail - parent (Part Aiman)
    mat4.translate(modelViewMatrix,modelViewMatrix,[-6,-10,83]); 
    
    
    var xChildTail = 0.0
   //1
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xChildTail, 0.0, zPositionObj]);  // amount to translate

    const buffersTails = initBuffers(gl,positionsBox,orangeColor);
    var axisToRotate = [0, 0, 1]; 
    drawScene(gl, programInfo, buffersTails, tailRotation, axisToRotate, modelViewMatrix, projectionMatrix);
    //1
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildTail, 0.0, zPositionObj]);  // amount to translate
    
    const buffersTail1 = initBuffers(gl,positionsBox,orangeColor);
    var axisToRotate = [1, 0, 0]; 
    drawScene(gl, programInfo, buffersTail1, tailRotation, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //2
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildTail +2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersTail2 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersTail2, tailRotation, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

    //3
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildTail+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersTail3 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersTail3, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

    //4
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildTail +2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersTail4 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersTail4, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

     //5
     mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildTail +0.0, 2.0, 0.0]);  // amount to translate

    const buffersTail5 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersTail5, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

    //6
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildTail -2.0, 0.0, 0.0]);  // amount to translate
 
     const buffersTail6 = initBuffers(gl,positionsBox,orangeColor);
     axisToRotate = [0, 0, 0]; 
     drawScene(gl, programInfo, buffersTail6, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
     gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

     //7
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildTail -4.0, 0.0, 0.0]);  // amount to translate

    const buffersTail7 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersTail7, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

         //8
         mat4.translate(modelViewMatrix,     // destination matrix
         modelViewMatrix,     // matrix to translate
         [xChildTail +0.0, 0.0, 0.0]);  // amount to translate

    const buffersTail8 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersTail8, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

    //9
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

    const buffersTail9 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersTail9, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

    //10
    mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +0.0, 2.0, 0.0]);  // amount to translate

    const buffersTail10 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersTail10, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

    //11
    mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail -2.0, 0.0, 0.0]);  // amount to translate

    const buffersTail11 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersTail11, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

    //12
    mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +6.0, 0.0, 0.0]);  // amount to translate

    const buffersTail12 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersTail12, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

    //13
    mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail -2.0, 0.0, 0.0]);  // amount to translate

    const buffersTail13 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersTail13, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

    //14
    mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +0.0, 0.0, 0.0]);  // amount to translate

    const buffersTail14 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersTail14, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);


  //15
        mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xChildTail -4.0, 2.0, 0.0]);  // amount to translate

        const buffersTail15 = initBuffers(gl,positionsBox,orangeColor);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersTail15, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
        
        //16
        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate
      
        const buffersTail16 = initBuffers(gl,positionsBox,orangeColor);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersTail16, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    
        //17
        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xChildTail+2.0, 0.0, 0.0]);  // amount to translate
      
        const buffersTail17 = initBuffers(gl,positionsBox,darkOrangeColor2);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersTail17, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    
        //18
        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate
    
        const buffersTail18 = initBuffers(gl,positionsBox,orangeColor);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersTail18, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    
         //19
         mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xChildTail +0.0, 2.0, 0.0]);  // amount to translate
    
        const buffersTail19 = initBuffers(gl,positionsBox,darkOrangeColor2);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersTail19, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    
        //20
        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xChildTail -2.0, 0.0, 0.0]);  // amount to translate
     
         const buffersTail20 = initBuffers(gl,positionsBox,orangeColor);
         axisToRotate = [0, 0, 0]; 
         drawScene(gl, programInfo, buffersTail20, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
         gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    
         //21
        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xChildTail -4.0, 0.0, 0.0]);  // amount to translate
    
        const buffersTail21 = initBuffers(gl,positionsBox,orangeColor);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersTail21, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    
             //22
             mat4.translate(modelViewMatrix,     // destination matrix
             modelViewMatrix,     // matrix to translate
             [xChildTail +0.0, 0.0, 0.0]);  // amount to translate
    
        const buffersTail22 = initBuffers(gl,positionsBox,orangeColor);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersTail22, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    
        //23
        mat4.translate(modelViewMatrix,     // destination matrix
                        modelViewMatrix,     // matrix to translate
                        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate
    
        const buffersTai23 = initBuffers(gl,positionsBox,orangeColor);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersTai23, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    
        //24
        mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xChildTail +0.0, 2.0, 0.0]);  // amount to translate
    
        const buffersTail24 = initBuffers(gl,positionsBox,darkOrangeColor2);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersTail24, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    
        //25
        mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xChildTail -2.0, 0.0, 0.0]);  // amount to translate
    
        const buffersTail25 = initBuffers(gl,positionsBox,orangeColor);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersTail25, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    
        //26
        mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xChildTail +6.0, 0.0, 0.0]);  // amount to translate
    
        const buffersTail26 = initBuffers(gl,positionsBox,orangeColor);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersTail26, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    
        //27
        mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xChildTail -2.0, 0.0, 0.0]);  // amount to translate
    
        const buffersTail27 = initBuffers(gl,positionsBox,darkOrangeColor2);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersTail27, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    
        //28
        mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xChildTail +0.0, 0.0, 0.0]);  // amount to translate
    
        const buffersTail28 = initBuffers(gl,positionsBox,darkOrangeColor);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersTail28, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //29
        mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xChildTail +2.0, 0.0, 2.0]);  // amount to translate
    
        const buffersTail29 = initBuffers(gl,positionsBox,darkOrangeColor);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersTail29, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //30
        mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xChildTail -2.0, 0.0, 0.0]);  // amount to translate
    
        const buffersTail30 = initBuffers(gl,positionsBox,orangeColor);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersTail30, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //31
        mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xChildTail -2.0, 0.0, 0.0]);  // amount to translate
    
        const buffersTail31 = initBuffers(gl,positionsBox,darkOrangeColor);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersTail31, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //32
              mat4.translate(modelViewMatrix,     // destination matrix
              modelViewMatrix,     // matrix to translate
              [xChildTail -2.0, 0.0, 0.0]);  // amount to translate
      
          const buffersTail32 = initBuffers(gl,positionsBox,darkOrangeColor);
          axisToRotate = [0, 0, 0]; 
          drawScene(gl, programInfo, buffersTail32, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
          gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

          //33
          mat4.translate(modelViewMatrix,     // destination matrix
          modelViewMatrix,     // matrix to translate
          [xChildTail +0.0, -2.0, 0.0]);  // amount to translate
  
      const buffersTail33 = initBuffers(gl,positionsBox,darkOrangeColor);
      axisToRotate = [0, 0, 0]; 
      drawScene(gl, programInfo, buffersTail33, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
      gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

      //34
      mat4.translate(modelViewMatrix,     // destination matrix
      modelViewMatrix,     // matrix to translate
      [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

        const buffersTail34 = initBuffers(gl,positionsBox,orangeColor);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersTail34, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //35
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

        const buffersTail35 = initBuffers(gl,positionsBox,orangeColor);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersTail35, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //36
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

        const buffersTail36 = initBuffers(gl,positionsBox,orangeColor);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersTail36, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //37
                mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xChildTail -6.0, -2.0, 0.0]);  // amount to translate
        
            const buffersTail37 = initBuffers(gl,positionsBox,darkOrangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail37, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

            //38
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

        const buffersTail38 = initBuffers(gl,positionsBox,orangeColor);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersTail38, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //39
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

        const buffersTail39 = initBuffers(gl,positionsBox,orangeColor);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersTail39, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //40
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

        const buffersTail40 = initBuffers(gl,positionsBox,darkOrangeColor);
        axisToRotate = [0, 0, 0]; 
        drawScene(gl, programInfo, buffersTail40, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
        gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);



        //41
            mat4.translate(modelViewMatrix,     // destination matrix
                modelViewMatrix,     // matrix to translate
                [xChildTail -6.0, -2.0, 0.0]);  // amount to translate
        
            const buffersTail41 = initBuffers(gl,positionsBox,orangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail41, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //42
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

                const buffersTail42 = initBuffers(gl,positionsBox,darkOrangeColor);
                axisToRotate = [0, 0, 0]; 
                drawScene(gl, programInfo, buffersTail42, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //43
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

                const buffersTail43 = initBuffers(gl,positionsBox,darkOrangeColor);
                axisToRotate = [0, 0, 0]; 
                drawScene(gl, programInfo, buffersTail43, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //44
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

                const buffersTail44 = initBuffers(gl,positionsBox,orangeColor);
                axisToRotate = [0, 0, 0]; 
                drawScene(gl, programInfo, buffersTail44, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //45
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xChildTail -6.0, -2.0, 0.0]);  // amount to translate

                const buffersTail45 = initBuffers(gl,positionsBox,orangeColor);
                axisToRotate = [0, 0, 0]; 
                drawScene(gl, programInfo, buffersTail45, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //46
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

                const buffersTail46 = initBuffers(gl,positionsBox,orangeColor);
                axisToRotate = [0, 0, 0]; 
                drawScene(gl, programInfo, buffersTail46, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //47
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

                const buffersTail47 = initBuffers(gl,positionsBox,orangeColor);
                axisToRotate = [0, 0, 0]; 
                drawScene(gl, programInfo, buffersTail47, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //48
            mat4.translate(modelViewMatrix,     // destination matrix
            modelViewMatrix,     // matrix to translate
            [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

                const buffersTail48 = initBuffers(gl,positionsBox,orangeColor);
                axisToRotate = [0, 0, 0]; 
                drawScene(gl, programInfo, buffersTail48, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
                gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //49
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail -6.0, -2.0, 0.0]);  // amount to translate

            const buffersTail49 = initBuffers(gl,positionsBox,darkOrangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail49, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //50
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail50 = initBuffers(gl,positionsBox,darkOrangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail50, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //51
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail51 = initBuffers(gl,positionsBox,orangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail51, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //52
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail52 = initBuffers(gl,positionsBox,orangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail52, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //white tail
        //53
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +0.0, -2.0, 0.0]);  // amount to translate

            const buffersTail53 = initBuffers(gl,positionsBox,orangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail53, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //54
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail -2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail54 = initBuffers(gl,positionsBox,whiteColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail54, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //55
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail -2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail55 = initBuffers(gl,positionsBox,whiteColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail55, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //56
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail -2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail56 = initBuffers(gl,positionsBox,whiteColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail56, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //57
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +6.0, -2.0, 0.0]);  // amount to translate

            const buffersTail57 = initBuffers(gl,positionsBox,greyColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail57, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //58
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail -2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail58 = initBuffers(gl,positionsBox,darkGreyColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail58, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //59
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail -2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail59 = initBuffers(gl,positionsBox,whiteColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail59, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //60
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail -2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail60 = initBuffers(gl,positionsBox,darkGreyColor1);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail60, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //61
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +6.0, 2.0, -2.0]);  // amount to translate

            const buffersTail61 = initBuffers(gl,positionsBox,orangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail61, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //62
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail -2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail62 = initBuffers(gl,positionsBox,greyColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail62, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //63
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail -2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail63 = initBuffers(gl,positionsBox,whiteColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail63, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //64
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail -2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail64 = initBuffers(gl,positionsBox,orangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail64, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //65
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +6.0, -2.0, 0.0]);  // amount to translate

            const buffersTail65 = initBuffers(gl,positionsBox,whiteColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail65, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //66
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail -2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail66 = initBuffers(gl,positionsBox,darkGreyColor1);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail66, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //67
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail -2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail67 = initBuffers(gl,positionsBox,darkGreyColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail67, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //68
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail -2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail68 = initBuffers(gl,positionsBox,darkGreyColor1);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail68, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //69
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +0.0, 0.0, 4.0]);  // amount to translate

            const buffersTail69 = initBuffers(gl,positionsBox,darkGreyColor1);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail69, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //70
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail70 = initBuffers(gl,positionsBox,whiteColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail70, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //71
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail71 = initBuffers(gl,positionsBox,darkGreyColor1);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail71, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //72
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail72 = initBuffers(gl,positionsBox,darkGreyColor1);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail72, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //73
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail -6.0, 2.0, 0.0]);  // amount to translate

            const buffersTail73 = initBuffers(gl,positionsBox,whiteColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail73, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //74
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail74 = initBuffers(gl,positionsBox,orangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail74, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //75
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail75 = initBuffers(gl,positionsBox,darkGreyColor1);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail75, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //76
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail76 = initBuffers(gl,positionsBox,darkOrangeColor2);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail76, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //77
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail -6.0, 2.0, 0.0]);  // amount to translate

            const buffersTail77 = initBuffers(gl,positionsBox,orangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail77, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //78
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail78 = initBuffers(gl,positionsBox,darkOrangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail74, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //79
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail79 = initBuffers(gl,positionsBox,orangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail79, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //80
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail80 = initBuffers(gl,positionsBox,darkOrangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail80, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //81
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail -6.0, 2.0, 0.0]);  // amount to translate

            const buffersTail81 = initBuffers(gl,positionsBox,darkOrangeColor2);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail81, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //82
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail82 = initBuffers(gl,positionsBox,darkOrangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail82, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //83
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail83 = initBuffers(gl,positionsBox,orangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail83, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //84
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail84 = initBuffers(gl,positionsBox,orangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail84, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //85
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail -6.0, 2.0, 0.0]);  // amount to translate

            const buffersTail85 = initBuffers(gl,positionsBox,darkOrangeColor2);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail85, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //86
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail86 = initBuffers(gl,positionsBox,orangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail86, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //87
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail87 = initBuffers(gl,positionsBox,orangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail87, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //88
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail88 = initBuffers(gl,positionsBox,orangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail84, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //89
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail -6.0, 2.0, 0.0]);  // amount to translate

            const buffersTail89 = initBuffers(gl,positionsBox,orangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail89, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //90
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail90 = initBuffers(gl,positionsBox,orangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail90, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //91
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail91 = initBuffers(gl,positionsBox,darkOrangeColor2);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail91, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //92
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail92 = initBuffers(gl,positionsBox,darkOrangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail92, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //93
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail -6.0, 2.0, 0.0]);  // amount to translate

            const buffersTail93 = initBuffers(gl,positionsBox,orangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail93, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //94
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail94 = initBuffers(gl,positionsBox,darkOrangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail90, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //95
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail95 = initBuffers(gl,positionsBox,orangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail95, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //96
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail96 = initBuffers(gl,positionsBox,darkOrangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail96, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);


        //97
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail -6.0, 2.0, 0.0]);  // amount to translate

            const buffersTail97 = initBuffers(gl,positionsBox,orangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail97, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //98
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail98 = initBuffers(gl,positionsBox,darkOrangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail98, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //99
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail99 = initBuffers(gl,positionsBox,orangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail99, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

        //100
        mat4.translate(modelViewMatrix,     // destination matrix
        modelViewMatrix,     // matrix to translate
        [xChildTail +2.0, 0.0, 0.0]);  // amount to translate

            const buffersTail100 = initBuffers(gl,positionsBox,darkOrangeColor);
            axisToRotate = [0, 0, 0]; 
            drawScene(gl, programInfo, buffersTail100, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
            gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    

    // DRAW FOX LEGS - parent (Part Firdaus)
    mat4.translate(modelViewMatrix,modelViewMatrix,[-10,40,42]); 
    var xLeg1 = 0.0
    //1
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1, 0.0, zPositionObj]);  // amount to translate
    
    const buffersLeg = initBuffers(gl,positionsBox,darkOrangeColor2);
    var axisToRotate = [1, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg, legRotation, axisToRotate, modelViewMatrix, projectionMatrix);
    //1
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1, 0.0, zPositionObj]);  // amount to translate
    
    const buffersLeg1 = initBuffers(gl,positionsBox,darkOrangeColor2);
    var axisToRotate = [0, 0, 1]; 
    drawScene(gl, programInfo, buffersLeg1, legRotation, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //2
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLeg2 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg2, legRotation, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //3
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+4.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLeg3 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg3, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //4
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLeg4 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg4, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //5
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg5 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg5, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //6
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLeg6 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg6, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //7
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1-2.0, 0.0, 0.0]);  // amount to translate

    const buffersLeg7 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg7, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //8
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLeg8 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg8, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //9
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg9 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg9, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //10
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+2, 0.0, 0.0]);  // amount to translate
  
    const buffersLeg10 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg10, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //11
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+2, 0.0, 0.0]);  // amount to translate
  
    const buffersLeg11 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg11, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //12
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+2, 0.0, 0.0]);  // amount to translate
  
    const buffersLeg12 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg12, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //13
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg13 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg13, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //14
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLeg14 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg14, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //15
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLeg15 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg15, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //16
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLeg16 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg16, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //17
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg17 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg17, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //18
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLeg18 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg18, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //19
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLeg19 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg19, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //20
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLeg20 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg20, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //21
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg21 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg21, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //22
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLeg22 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg22, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //23
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLeg23 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg23, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //24
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLeg24 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg24, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //25
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg25 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg25, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //26
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLeg26 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg26, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //27
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLeg27 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg27, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //28
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLeg28 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg28, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //29
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg29 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg29, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //30
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLeg30 = initBuffers(gl,positionsBox,legBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg30, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //31
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLeg31 = initBuffers(gl,positionsBox,legBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg31, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //32
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLeg32 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg32, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //33
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+6.0, 0.0, 2.0]);  // amount to translate
  
    const buffersLeg33 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg33, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //34
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLeg34 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg34, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //35
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLeg35 = initBuffers(gl,positionsBox,legLightBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg35, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //36
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLeg36 = initBuffers(gl,positionsBox,legLightBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg36, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //37
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLeg37 = initBuffers(gl,positionsBox,legLightBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg37, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //38
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLeg38 = initBuffers(gl,positionsBox,legLightBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg38, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //39
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLeg39 = initBuffers(gl,positionsBox,legLightBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg39, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //40
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLeg40 = initBuffers(gl,positionsBox,legLightBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg40, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //41
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, 0.0, 2.0]);  // amount to translate
  
    const buffersLeg41 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg41, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //42
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg42 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg42, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //43
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg43 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg43, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //44
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg44 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg44, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //45
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg45 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg45, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //46
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg46 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg46, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //47
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg47 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg47, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //48
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg48 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg48, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //49
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, 0.0, 2.0]);  // amount to translate
  
    const buffersLeg49 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg49, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //50
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLeg50 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg50, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //51
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLeg51 = initBuffers(gl,positionsBox,legDarkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg51, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //52
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLeg52 = initBuffers(gl,positionsBox,legDarkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg52, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //53
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLeg53 = initBuffers(gl,positionsBox,legDarkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg53, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //54
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLeg54 = initBuffers(gl,positionsBox,legDarkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg54, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //55
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLeg55 = initBuffers(gl,positionsBox,legDarkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg55, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //56
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLeg56 = initBuffers(gl,positionsBox,legDarkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg56, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //57
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1-2.0, +0.0, 0.0]);  // amount to translate
  
    const buffersLeg57 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg57, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //58
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg58 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg58, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //59
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg59 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg59, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //60
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg60 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg60, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //61
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg61 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg61, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //62
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg62 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg62, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //63
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg63 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg63, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //64
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg64 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg64, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //65
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLeg65 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg65, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //66
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLeg66 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg66, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //67
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLeg67 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg67, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //68
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLeg68 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg68, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //69
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLeg69 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg69, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //70
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLeg70 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg70, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //71
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLeg71 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg71, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //72
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLeg72 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg72, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //73
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLeg73 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg73, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //74
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg74 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg74, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //75
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg75 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg75, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //76
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg76 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg76, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //77
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg77 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg77, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //78
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg78 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg78, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //79
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg79 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg79, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //80
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg80 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg80, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //81
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, 0.0, -2.0]);  // amount to translate
  
    const buffersLeg81 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg81, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //82
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLeg82 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg82, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //83
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLeg83 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg83, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //84
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLeg84 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg84, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //85
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLeg85 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg85, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //86
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLeg86 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg86, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //87
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLeg87 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg87, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //88
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLeg88 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg88, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //89
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, 0.0, -2.0]);  // amount to translate
  
    const buffersLeg89 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg89, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //90
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg90 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg90, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //91
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg91 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg91, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //92
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg92 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg92, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //93
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg93 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg93, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //94
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg94 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg94, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //95
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg95 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg95, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //96
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg1+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLeg96 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLeg96, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

    mat4.translate(modelViewMatrix,modelViewMatrix,[-8,14,78]); 
    var xLeg2 = 0.0
    //1
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2, 0.0, zPositionObj]);  // amount to translate
    
    const buffersLegP2 = initBuffers(gl,positionsBox,darkOrangeColor2);
    var axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP2, legRotation, axisToRotate, modelViewMatrix, projectionMatrix);
    //1
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2, 0.0, zPositionObj]);  // amount to translate
    
    const buffersLegP21 = initBuffers(gl,positionsBox,darkOrangeColor2);
    var axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP21, legRotation, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //2
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP22 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP22, legRotation, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //3
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+4.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP23 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP23, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //4
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP24 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP24, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //5
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP25 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP25, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //6
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP26 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP26, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //7
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2-2.0, 0.0, 0.0]);  // amount to translate

    const buffersLegP27 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP27, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //8
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP28 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP28, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //9
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP29 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP29, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //10
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+2, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP210 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP210, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //11
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+2, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP211 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP211, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //12
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+2, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP212 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP212, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //13
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP213 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP213, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //14
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP214 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP214, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //15
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP215 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP215, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //16
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP216 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP216, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //17
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP217 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP217, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //18
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP218 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP218, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //19
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP219 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP219, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //20
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP220 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP220, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //21
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP221 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP221, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //22
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP222 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP222, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //23
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP223 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP223, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //24
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP224 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP224, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //25
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP225 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP225, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //26
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP226 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP226, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //27
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP227 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP227, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //28
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP228 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP228, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //29
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP229 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP229, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //30
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP230 = initBuffers(gl,positionsBox,legBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP230, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //31
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP231 = initBuffers(gl,positionsBox,legBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP231, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //32
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP232 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP232, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //33
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+6.0, 0.0, 2.0]);  // amount to translate
  
    const buffersLegP233 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP233, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //34
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP234 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP234, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //35
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP235 = initBuffers(gl,positionsBox,legLightBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP235, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //36
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP236 = initBuffers(gl,positionsBox,legLightBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP236, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //37
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP237 = initBuffers(gl,positionsBox,legLightBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP237, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //38
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP238 = initBuffers(gl,positionsBox,legLightBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP238, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //39
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP239 = initBuffers(gl,positionsBox,legLightBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP239, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //40
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP240 = initBuffers(gl,positionsBox,legLightBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP240, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //41
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, 0.0, 2.0]);  // amount to translate
  
    const buffersLegP241 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP241, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //42
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP242 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP242, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //43
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP243 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP243, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //44
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP244 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP244, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //45
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP245 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP245, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //46
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP246 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP246, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //47
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP247 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP247, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //48
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP248 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP248, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //49
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, 0.0, 2.0]);  // amount to translate
  
    const buffersLegP249 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP249, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //50
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP250 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP250, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //51
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP251 = initBuffers(gl,positionsBox,legDarkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP251, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //52
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP252 = initBuffers(gl,positionsBox,legDarkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP252, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //53
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP253 = initBuffers(gl,positionsBox,legDarkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP253, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //54
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP254 = initBuffers(gl,positionsBox,legDarkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP254, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //55
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP255 = initBuffers(gl,positionsBox,legDarkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP255, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //56
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP256 = initBuffers(gl,positionsBox,legDarkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP256, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //57
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2-2.0, +0.0, 0.0]);  // amount to translate
  
    const buffersLegP257 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP257, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //58
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP258 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP258, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //59
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP259 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP259, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //60
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP260 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP260, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //61
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP261 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP261, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //62
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP262 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP262, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //63
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP263 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP263, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //64
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP264 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP264, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //65
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP265 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP265, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //66
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP266 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP266, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //67
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP267 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP267, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //68
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP268 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP268, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //69
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP269 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP269, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //70
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP270 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP270, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //71
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP271 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP271, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //72
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP272 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP272, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //73
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP273 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP273, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //74
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP274 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP274, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //75
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP275 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP275, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //76
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP276 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP276, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //77
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP277 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP277, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //78
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP278 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP278, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //79
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP279 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP279, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //80
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP280 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP280, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //81
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, 0.0, -2.0]);  // amount to translate
  
    const buffersLegP281 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP281, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //82
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLegP282 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP282, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //83
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLegP283 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP283, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //84
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLegP284 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP284, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //85
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLegP285 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP285, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //86
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLegP286 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP286, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //87
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLegP287 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP287, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //88
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLegP288 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP288, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //89
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, 0.0, -2.0]);  // amount to translate
  
    const buffersLegP289 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP289, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //90
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP290 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP290, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //91
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP291 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP291, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //92
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP292 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP292, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //93
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP293 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP293, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //94
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP294 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP294, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //95
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP295 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP295, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //96
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xLeg2+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP296 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP296, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

    mat4.translate(modelViewMatrix,modelViewMatrix,[12,14,92]); 
    var xleg3 = 0.0
    //1
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3, 0.0, zPositionObj]);  // amount to translate
    
    const buffersLegP3 = initBuffers(gl,positionsBox,darkOrangeColor2);
    var axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP3, legRotation, axisToRotate, modelViewMatrix, projectionMatrix);
    //1
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3, 0.0, zPositionObj]);  // amount to translate
    
    const buffersLegP31 = initBuffers(gl,positionsBox,darkOrangeColor2);
    var axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP31, legRotation, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //2
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP32 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP32, legRotation, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //3
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+4.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP33 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP33, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //4
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP34 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP34, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //5
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP35 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP35, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //6
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP36 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP36, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //7
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3-2.0, 0.0, 0.0]);  // amount to translate

    const buffersLegP37 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP37, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //8
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP38 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP38, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //9
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP39 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP39, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //10
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+2, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP310 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP310, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //11
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+2, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP311 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP311, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //12
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+2, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP312 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP312, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //13
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP313 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP313, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //14
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP314 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP314, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //15
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP315 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP315, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //16
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP316 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP316, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //17
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP317 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP317, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //18
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP318 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP318, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //19
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP319 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP319, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //20
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP320 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP320, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //21
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP321 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP321, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //22
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP322 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP322, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //23
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP323 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP323, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //24
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP324 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP324, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //25
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP325 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP325, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //26
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP326 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP326, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //27
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP327 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP327, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //28
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP328 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP328, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //29
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP329 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP329, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //30
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP330 = initBuffers(gl,positionsBox,legBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP330, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //31
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP331 = initBuffers(gl,positionsBox,legBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP331, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //32
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP332 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP332, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //33
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+6.0, 0.0, 2.0]);  // amount to translate
  
    const buffersLegP333 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP333, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //34
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP334 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP334, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //35
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP335 = initBuffers(gl,positionsBox,legLightBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP335, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //36
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP336 = initBuffers(gl,positionsBox,legLightBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP336, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //37
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP337 = initBuffers(gl,positionsBox,legLightBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP337, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //38
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP338 = initBuffers(gl,positionsBox,legLightBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP338, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //39
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP339 = initBuffers(gl,positionsBox,legLightBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP339, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //40
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP340 = initBuffers(gl,positionsBox,legLightBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP340, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //41
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, 0.0, 2.0]);  // amount to translate
  
    const buffersLegP341 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP341, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //42
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP342 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP342, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //43
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP343 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP343, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //44
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP344 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP344, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //45
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP345 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP345, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //46
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP346 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP346, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //47
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP347 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP347, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //48
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP348 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP348, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //49
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, 0.0, 2.0]);  // amount to translate
  
    const buffersLegP349 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP349, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //50
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP350 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP350, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //51
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP351 = initBuffers(gl,positionsBox,legDarkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP351, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //52
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP352 = initBuffers(gl,positionsBox,legDarkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP352, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //53
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP353 = initBuffers(gl,positionsBox,legDarkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP353, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //54
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP354 = initBuffers(gl,positionsBox,legDarkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP354, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //55
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP355 = initBuffers(gl,positionsBox,legDarkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP355, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //56
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP356 = initBuffers(gl,positionsBox,legDarkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP356, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //57
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3-2.0, +0.0, 0.0]);  // amount to translate
  
    const buffersLegP357 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP357, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //58
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP358 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP358, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //59
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP359 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP359, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //60
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP360 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP360, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //61
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP361 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP361, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //62
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP362 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP362, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //63
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP363 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP363, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //64
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP364 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP364, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //65
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP365 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP365, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //66
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP366 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP366, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //67
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP367 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP367, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //68
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP368 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP368, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //69
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP369 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP369, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //70
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP370 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP370, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //71
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP371 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP371, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //72
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP372 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP372, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //73
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP373 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP373, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //74
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP374 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP374, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //75
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP375 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP375, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //76
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP376 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP376, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //77
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP377 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP377, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //78
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP378 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP378, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //79
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP379 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP379, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //80
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP380 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP380, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //81
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, 0.0, -2.0]);  // amount to translate
  
    const buffersLegP381 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP381, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //82
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLegP382 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP382, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //83
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLegP383 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP383, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //84
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLegP384 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP384, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //85
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLegP385 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP385, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //86
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLegP386 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP386, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //87
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLegP387 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP387, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //88
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLegP388 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP388, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //89
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, 0.0, -2.0]);  // amount to translate
  
    const buffersLegP389 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP389, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //90
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP390 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP390, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //91
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP391 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP391, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //92
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP392 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP392, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //93
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP393 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP393, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //94
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP394 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP394, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //95
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP395 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP395, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //96
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg3+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP396 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP396, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

    mat4.translate(modelViewMatrix,modelViewMatrix,[-8,14,78]); 
    var xleg4 = 0.0
    //1
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4, 0.0, zPositionObj]);  // amount to translate
    
    const buffersLegP4 = initBuffers(gl,positionsBox,darkOrangeColor2);
    var axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP4, legRotation, axisToRotate, modelViewMatrix, projectionMatrix);
    //1
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4, 0.0, zPositionObj]);  // amount to translate
    
    const buffersLegP41 = initBuffers(gl,positionsBox,darkOrangeColor2);
    var axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP41, legRotation, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //2
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP42 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP42, legRotation, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //3
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+4.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP43 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP43, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //4
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP44 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP44, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //5
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP45 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP45, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //6
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP46 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP46, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //7
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4-2.0, 0.0, 0.0]);  // amount to translate

    const buffersLegP47 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP47, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //8
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP48 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP48, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //9
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP49 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP49, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //10
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+2, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP410 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP410, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //11
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+2, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP411 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP411, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //12
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+2, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP412 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP412, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //13
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP413 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP413, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //14
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP414 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP414, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //15
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP415 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP415, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //16
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP416 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP416, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //17
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP417 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP417, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //18
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP418 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP418, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //19
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP419 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP419, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //20
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP420 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP420, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //21
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP421 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP421, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //22
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP422 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP422, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //23
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP423 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP423, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //24
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP424 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP424, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //25
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP425 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP425, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //26
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP426 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP426, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //27
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP427 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP427, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //28
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP428 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP428, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //29
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP429 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP429, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //30
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP430 = initBuffers(gl,positionsBox,legBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP430, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //31
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP431 = initBuffers(gl,positionsBox,legBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP431, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //32
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP432 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP432, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //33
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+6.0, 0.0, 2.0]);  // amount to translate
  
    const buffersLegP433 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP433, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //34
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP434 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP434, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //35
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP435 = initBuffers(gl,positionsBox,legLightBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP435, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //36
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP436 = initBuffers(gl,positionsBox,legLightBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP436, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //37
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP437 = initBuffers(gl,positionsBox,legLightBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP437, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //38
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP438 = initBuffers(gl,positionsBox,legLightBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP438, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //39
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP439 = initBuffers(gl,positionsBox,legLightBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP439, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //40
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP440 = initBuffers(gl,positionsBox,legLightBrownColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP440, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //41
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, 0.0, 2.0]);  // amount to translate
  
    const buffersLegP441 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP441, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //42
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP442 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP442, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //43
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP443 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP443, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //44
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP444 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP444, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //45
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP445 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP445, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //46
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP446 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP446, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //47
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP447 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP447, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //48
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP448 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP448, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //49
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, 0.0, 2.0]);  // amount to translate
  
    const buffersLegP449 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP449, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //50
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP450 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP450, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //51
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP451 = initBuffers(gl,positionsBox,legDarkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP451, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //52
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP452 = initBuffers(gl,positionsBox,legDarkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP452, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //53
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP453 = initBuffers(gl,positionsBox,legDarkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP453, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //54
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP454 = initBuffers(gl,positionsBox,legDarkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP454, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //55
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP455 = initBuffers(gl,positionsBox,legDarkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP455, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //56
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP456 = initBuffers(gl,positionsBox,legDarkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP456, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //57
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4-2.0, +0.0, 0.0]);  // amount to translate
  
    const buffersLegP457 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP457, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //58
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP458 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP458, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //59
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP459 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP459, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //60
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP460 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP460, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //61
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP461 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP461, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //62
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP462 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP462, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //63
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP463 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP463, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //64
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP464 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP464, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //65
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP465 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP465, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //66
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP466 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP466, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //67
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP467 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP467, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //68
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP468 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP468, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //69
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP469 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP469, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //70
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP470 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP470, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //71
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP471 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP471, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //72
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, +2.0, 0.0]);  // amount to translate
  
    const buffersLegP472 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP472, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //73
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersLegP473 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP473, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //74
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP474 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP474, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //75
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP475 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP475, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //76
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP476 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP476, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //77
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP477 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP477, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //78
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP478 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP478, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //79
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP479 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP479, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //80
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP480 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP480, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //81
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, 0.0, -2.0]);  // amount to translate
  
    const buffersLegP481 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP481, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //82
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLegP482 = initBuffers(gl,positionsBox,legBlackCOlor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP482, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //83
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLegP483 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP483, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //84
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLegP484 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP484, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //85
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLegP485 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP485, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //86
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLegP486 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP486, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //87
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLegP487 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP487, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //88
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersLegP488 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP488, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //89
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, 0.0, -2.0]);  // amount to translate
  
    const buffersLegP489 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP489, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //90
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP490 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP490, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //91
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP491 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP491, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //92
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP492 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP492, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //93
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP493 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP493, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //94
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP494 = initBuffers(gl,positionsBox,softOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP494, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //95
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP495 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP495, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //96
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xleg4+0.0, -2.0, 0.0]);  // amount to translate
  
    const buffersLegP496 = initBuffers(gl,positionsBox,legGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersLegP496, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

    // DRAW FOX HEAD - parent (Part Luqman)
    
    mat4.translate(modelViewMatrix,modelViewMatrix,[7,15,15]); 
    
    var xChildHead = 0.0;
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead, 0.0, 0.0]);  // amount to translate
    
    const buffersFace02 = initBuffers(gl,positionsBox,greyColor);
    var axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace02, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

    
    //1
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead, 0.0, 0.0]);  // amount to translate
    
    const buffersFace1 = initBuffers(gl,positionsBox,whiteColor);
    var axisToRotate = [0, 0, 1]; 
    drawScene(gl, programInfo, buffersFace1, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //2
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersFace2 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace2, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //3
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersFace3 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace3, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //4
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersFace4 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace4, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //5
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+8.0, 0.0, 0.0]);  // amount to translate
  
    const buffersFace5 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace5, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //6
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersFace6 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace6, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //7
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersFace7 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace7, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //8
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersFace8 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace8, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //9
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersFace9 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace9, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //10
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersFace10 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace10, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //11
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersFace11 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace11, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //12
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersFace12 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace12, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //13
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersFace13 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace13, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //14
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersFace14 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace14, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //15
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersFace15 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace15, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //16
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersFace16 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace16, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //17
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersFace17 = initBuffers(gl,positionsBox,blackColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace17, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //18
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersFace18 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace18, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //19
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersFace19 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace19, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //20
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersFace20 = initBuffers(gl,positionsBox,brightOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace20, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //21
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersFace21 = initBuffers(gl,positionsBox,brightOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace21, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //22
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersFace22 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace22, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //23
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersFace23 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace23, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //24
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersFace24 = initBuffers(gl,positionsBox,blackColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace24, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //25
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 2.0, 0.0]);  // amount to translate
  
    const buffersFace25 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace25, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //26
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersFace26 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace26, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //27
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersFace27 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace27, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //28
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersFace28 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace28, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //29
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate
  
    const buffersFace29 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace29, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //30
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace30 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace30, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //31
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace31 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace31, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //32
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace32 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace32, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //33
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 2.0, 0.0]);  // amount to translate

    const buffersFace33 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace33, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //34
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace34 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace34, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //35
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace35 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace35, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //36
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace36 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace36, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //37
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace37 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace37, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //38
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace38 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace38, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //39
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace39 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace39, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //40
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace40 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace40, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //41
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 2.0, 0.0]);  // amount to translate

    const buffersFace41 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace41, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //42
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace42 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace42, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //43
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace43 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace43, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //44
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace44 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace44, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //45
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace45 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace45, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //46
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace46 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace46, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //47
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace47 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace47, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //48
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace48 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace48, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //49
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace49 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace49, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //50
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace50 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace50, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //51
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace51 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace51, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //52
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace52 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace52, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //53
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace53 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace53, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //54
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, -2.0, 0.0]);  // amount to translate

    const buffersFace54 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace54, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //55
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace55 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace55, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //56
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace56 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace56, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //57
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace57 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace57, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //58
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace58 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace58, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //59
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, -2.0, 0.0]);  // amount to translate

    const buffersFace59 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace59, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //60
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace60 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace60, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //61
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace61 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace61, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //62
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace62 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace62, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //63
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace63 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace63, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //64
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, -2.0, 0.0]);  // amount to translate

    const buffersFace64 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace64, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //65
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace65 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace65, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //66
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace66 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace66, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //67
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace67 = initBuffers(gl,positionsBox,brightOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace67, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //68
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace68 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace68, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //69
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, -2.0, 0.0]);  // amount to translate

    const buffersFace69 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace69, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //70
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace70 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace70, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //71
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace71 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace71, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //72
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace72 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace72, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //73
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace73 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace73, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //74
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, -2.0, 0.0]);  // amount to translate

    const buffersFace74 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace74, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //75
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace75 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace75, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //76
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace76 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace76, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //77
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace77 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace77, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //78
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace78 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace78, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //79
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 10.0, 0.0]);  // amount to translate

    const buffersFace79 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace79, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //80
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace80 = initBuffers(gl,positionsBox,brightOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace80, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //81
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace81 = initBuffers(gl,positionsBox,brightOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace81, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //82
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace82 = initBuffers(gl,positionsBox,brightOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace82, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //83
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace83 = initBuffers(gl,positionsBox,brightOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace83, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //84
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace84 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace84, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //85
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace85 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace85, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //86
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace86 = initBuffers(gl,positionsBox,brightOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace86, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //87
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace87 = initBuffers(gl,positionsBox,brightOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace87, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //88
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace88 = initBuffers(gl,positionsBox,brightOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace88, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //89
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace89 = initBuffers(gl,positionsBox,brightOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace89, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //90
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace90 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace90, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //91
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace91 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace91, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //92
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace92 = initBuffers(gl,positionsBox,brightOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace92, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //93
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace93 = initBuffers(gl,positionsBox,brightOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace93, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //94
    mat4.translate(modelViewMatrix,     // destination matrix
    modelViewMatrix,     // matrix to translate
    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace94 = initBuffers(gl,positionsBox,brightOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace94, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //95
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace95 = initBuffers(gl,positionsBox,brightOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace95, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //96
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace96 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace96, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //97
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace97 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace97, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //98
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace98 = initBuffers(gl,positionsBox,brightOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace98, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //99
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace99 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace99, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //100
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace100 = initBuffers(gl,positionsBox,brightOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace100, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //101
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace101 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace101, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //102
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace102 = initBuffers(gl,positionsBox,darkOrangeColor2);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace102, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //103
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace103 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace103, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //104
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace104 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace104, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //105
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace105 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace105, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //106
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace106 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace106, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //107
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace107 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace107, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //108
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace108 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace108, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //109
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace109 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace109, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //110
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace110 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace110, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //111
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace111 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace111, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //112
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace112 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace112, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //113
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace113 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace113, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //114
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, -2.0, 0.0]);  // amount to translate

    const buffersFace114 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace114, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //115
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace115 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace115, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //116
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace116 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace116, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //117
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace117 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace117, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //118
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace118 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace118, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //119
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, -2.0, 0.0]);  // amount to translate

    const buffersFace119 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace119, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //120
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace120 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace120, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //121
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace121 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace121, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //123
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace123 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace123, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //124
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace124 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace124, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //125
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, -2.0, 0.0]);  // amount to translate

    const buffersFace125 = initBuffers(gl,positionsBox,orangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace125, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //126
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace126 = initBuffers(gl,positionsBox,brightOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace126, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //127
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace127 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace127, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //128
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace128 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace128, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //129
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace129 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace129, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //130
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, -2.0, 0.0]);  // amount to translate

    const buffersFace130 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace130, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //131
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace131 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace131, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //132
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace132 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace132, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //133
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace133 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace133, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //134
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace134 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace134, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //135
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, -2.0, 0.0]);  // amount to translate

    const buffersFace135 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace135, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //136
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace136 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace136, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //137
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace137 = initBuffers(gl,positionsBox,darkGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace137, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //138
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace138 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace138, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //139
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, -2.0]);  // amount to translate

    const buffersFace139 = initBuffers(gl,positionsBox,darkerOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace139, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //140
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace140 = initBuffers(gl,positionsBox,darkGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace140, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //141
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 2.0, 0.0]);  // amount to translate

    const buffersFace141 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace141, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //142
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 2.0, 0.0]);  // amount to translate

    const buffersFace142 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace142, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //143
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 2.0, 0.0]);  // amount to translate

    const buffersFace143 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace143, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //144
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 2.0, 0.0]);  // amount to translate

    const buffersFace144 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace144, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //145
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace145 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace145, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //146
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, -2.0, 0.0]);  // amount to translate

    const buffersFace146 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace146, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //147
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, -2.0, 0.0]);  // amount to translate

    const buffersFace147 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace147, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //148
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, -2.0, 0.0]);  // amount to translate

    const buffersFace148 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace148, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //149
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, -2.0, 0.0]);  // amount to translate

    const buffersFace149 = initBuffers(gl,positionsBox,darkGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace149, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //150
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace150 = initBuffers(gl,positionsBox,darkGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace150, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //151
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 2.0, 0.0]);  // amount to translate

    const buffersFace151 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace151, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //152
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 2.0, 0.0]);  // amount to translate

    const buffersFace152 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace152, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //153
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 2.0, 0.0]);  // amount to translate

    const buffersFace153 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace153, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //154
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 2.0, 0.0]);  // amount to translate

    const buffersFace154 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace154, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //155
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace155 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace155, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //156
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, -2.0, 0.0]);  // amount to translate

    const buffersFace156 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace156, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //157
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, -2.0, 0.0]);  // amount to translate

    const buffersFace157 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace157, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //158
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, -2.0, 0.0]);  // amount to translate

    const buffersFace158 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace158, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //159
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, -2.0, 0.0]);  // amount to translate

    const buffersFace159 = initBuffers(gl,positionsBox,darkGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace159, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //160
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace160 = initBuffers(gl,positionsBox,darkGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace160, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //161
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 2.0, 0.0]);  // amount to translate

    const buffersFace161 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace161, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //162
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 2.0, 0.0]);  // amount to translate

    const buffersFace162 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace162, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //163
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 2.0, 0.0]);  // amount to translate

    const buffersFace163 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace163, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //164
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 2.0, 0.0]);  // amount to translate

    const buffersFace164 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace164, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //165
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace165 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace165, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //166
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, -2.0, 0.0]);  // amount to translate

    const buffersFace166 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace166, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //167
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, -2.0, 0.0]);  // amount to translate

    const buffersFace167 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace167, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //168
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, -2.0, 0.0]);  // amount to translate

    const buffersFace168 = initBuffers(gl,positionsBox,whiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace168, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //169
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, -2.0, 0.0]);  // amount to translate

    const buffersFace169 = initBuffers(gl,positionsBox,darkGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace169, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //170
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace170 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace170, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //171
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace171 = initBuffers(gl,positionsBox,darkGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace171, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //171
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace172 = initBuffers(gl,positionsBox,darkGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace172, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //173
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace173 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace173, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //174
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace174 = initBuffers(gl,positionsBox,darkGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace174, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //175
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace175 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace175, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //176
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace176 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace176, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //177
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace177 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace177, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //178
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace178 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace178, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //179
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace179 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace179, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //180
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace180 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace180, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //181
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace181 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace181, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //182
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace182 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace182, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //183
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace183 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace183, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //184
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace184 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace184, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //185
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace185 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace185, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //186
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace186 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace186, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //187
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace187 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace187, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //188
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersFace188 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace188, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //189
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace189 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace189, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //190
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace190 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace190, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //191
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace191 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace191, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //192
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace192 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace192, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //193
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersFace193 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersFace193, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //Mouth
    //1
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 4.0]);  // amount to translate

    const buffersMouth = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersMouth, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //2
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersMouth2 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersMouth2, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //3
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersMouth3 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersMouth3, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //4
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersMouth4 = initBuffers(gl,positionsBox,greyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersMouth4, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //5
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 2.0, 0.0]);  // amount to translate

    const buffersMouth5 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersMouth5, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //6
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersMouth6 = initBuffers(gl,positionsBox,brightOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersMouth6, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //7
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersMouth7 = initBuffers(gl,positionsBox,brightOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersMouth7, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //8
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersMouth8 = initBuffers(gl,positionsBox,darkOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersMouth8, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //9
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 0.0, 2.0]);  // amount to translate

    const buffersMouth9 = initBuffers(gl,positionsBox,mouthGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersMouth9, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //10
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersMouth10 = initBuffers(gl,positionsBox,mouthBlackColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersMouth10, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //11
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersMouth11 = initBuffers(gl,positionsBox,mouthBlackColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersMouth11, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //12
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersMouth12 = initBuffers(gl,positionsBox,mouthGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersMouth12, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //13
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, -2.0, 0.0]);  // amount to translate

    const buffersMouth13 = initBuffers(gl,positionsBox,mouthWhiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersMouth13, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //14
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersMouth14 = initBuffers(gl,positionsBox,mouthGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersMouth14, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //15
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersMouth15 = initBuffers(gl,positionsBox,mouthGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersMouth15, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //16
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersMouth16 = initBuffers(gl,positionsBox,mouthWhiteColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersMouth16, cubeRotation1, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);

    //left ear
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 12.0, -6.0]);  // amount to translate

    const buffersEarLeft = initBuffers(gl,positionsBox,earGreyColor);
    axisToRotate = [1, 0, 0]; 
    drawScene(gl, programInfo, buffersEarLeft, earRotation, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //1
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-0.0, 0.0, 0.0]);  // amount to translate

    const buffersEarLeft1 = initBuffers(gl,positionsBox,earGreyColor);
    axisToRotate = [1, 0, 0]; 
    drawScene(gl, programInfo, buffersEarLeft1, earRotation, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //2
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersEarLeft2 = initBuffers(gl,positionsBox,earOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersEarLeft2, earRotation, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //3
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, 2.0, 0.0]);  // amount to translate

    const buffersEarLeft3 = initBuffers(gl,positionsBox,earBlackColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersEarLeft3, earRotation, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //4
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersEarLeft4 = initBuffers(gl,positionsBox,earBlackColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersEarLeft4, earRotation, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //5
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+10.0, 0.0, 0.0]);  // amount to translate

    const buffersEarLeft5 = initBuffers(gl,positionsBox,earBlackColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersEarLeft5, earRotation, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //6
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+2.0, 0.0, 0.0]);  // amount to translate

    const buffersEarLeft6 = initBuffers(gl,positionsBox,earBlackColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersEarLeft6, earRotation, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //7
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead+0.0, -2.0, 0.0]);  // amount to translate

    const buffersEarLeft7 = initBuffers(gl,positionsBox,earOrangeColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersEarLeft7, earRotation, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
    //8
    mat4.translate(modelViewMatrix,     // destination matrix
                    modelViewMatrix,     // matrix to translate
                    [xChildHead-2.0, 0.0, 0.0]);  // amount to translate

    const buffersEarLeft8 = initBuffers(gl,positionsBox,earGreyColor);
    axisToRotate = [0, 0, 0]; 
    drawScene(gl, programInfo, buffersEarLeft8, earRotation, axisToRotate, modelViewMatrix, projectionMatrix);
    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);    
    
    

}
var rotateX = 0, rotateY = 0, rotateZ = 0;
var translateZ = 0, scaleY = 1, rotateObject = 0;
var lightShade = true; // ** LIGHTING **

var cubeRotation1 = (0.0* 0.0174533), cubeRotation2 = (0.0* 0.0174533), cubeRotation3 = 0.0, tailRotation = (0.0* 0.0174533), legRotation = (270.0* 0.0174533), earRotation=(0.0* 0.0174533);
var fieldOfViewC1 = 45, zNear = 0.1, zFar = 1, zPosition = 0, zPositionObj = -40;
window.onload = main;

// ########################################### //
// initBuffers 
//
// Initialize the buffers we'll need. For this demo, we just
// have one object -- a simple three-dimensional cube.
//
function initBuffers(gl,positions,faceColors) {

    // Create a buffer for the square's positions.
    const positionBuffer = gl.createBuffer();

    // Select the positionBuffer as the one to apply buffer
    // operations to from here out.
    gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);

    // Now pass the list of positions into WebGL to build the
    // shape. We do this by creating a Float32Array from the
    // JavaScript array, then use it to fill the current buffer.
    gl.bufferData(gl.ARRAY_BUFFER,
                new Float32Array(positions),
                gl.STATIC_DRAW);

    // ** LIGHTING **
    // Set up the normals for the vertices, so that we can compute lighting.
    const normalBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, normalBuffer);

    // ** LIGHTING **
    const vertexNormals = [
        // Front
        0.0,  0.0,  1.0,
        0.0,  0.0,  1.0,
        0.0,  0.0,  1.0,
        0.0,  0.0,  1.0,

        // Back
        0.0,  0.0, -1.0,
        0.0,  0.0, -1.0,
        0.0,  0.0, -1.0,
        0.0,  0.0, -1.0,

        // Top
        0.0,  1.0,  0.0,
        0.0,  1.0,  0.0,
        0.0,  1.0,  0.0,
        0.0,  1.0,  0.0,

        // Bottom
        0.0, -1.0,  0.0,
        0.0, -1.0,  0.0,
        0.0, -1.0,  0.0,
        0.0, -1.0,  0.0,

        // Right
        1.0,  0.0,  0.0,
        1.0,  0.0,  0.0,
        1.0,  0.0,  0.0,
        1.0,  0.0,  0.0,

        // Left
        -1.0,  0.0,  0.0,
        -1.0,  0.0,  0.0,
        -1.0,  0.0,  0.0,
        -1.0,  0.0,  0.0
        ];

    // ** LIGHTING **
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertexNormals), gl.STATIC_DRAW);

    var colors = [];

    for (var j = 0; j < faceColors.length; ++j) {
        const c = faceColors[j];
        colors = colors.concat(c, c, c, c);
    }

    function changeColor() {
        // Generate a random color
        color = [Math.random(), Math.random(), Math.random()];
    
        // Set the new color as a uniform variable
        gl.uniform3fv(colorLocation, color);
    
        // Render the scene
        drawScene();
    }

    const colorBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, colorBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(colors), gl.STATIC_DRAW);

    // Build the element array buffer; this specifies the indices
    // into the vertex arrays for each face's vertices.
    const indexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer);

    // This array defines each face as two triangles, using the
    // indices into the vertex array to specify each triangle's
    // position.
    const indices = [
        0,  1,  2,      0,  2,  3,    // front
        4,  5,  6,      4,  6,  7,    // back
        8,  9,  10,     8,  10, 11,   // top
        12, 13, 14,     12, 14, 15,   // bottom
        16, 17, 18,     16, 18, 19,   // right
        20, 21, 22,     20, 22, 23,   // left
    ];

    // Now send the element array to GL

    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,
        new Uint16Array(indices), gl.STATIC_DRAW);

    return {
        position: positionBuffer,
        normal: normalBuffer, // ** LIGHTING **
        color: colorBuffer,
        indices: indexBuffer,
    };
}

// ########################################### //
// Draw the scene.
//
function drawScene(gl, programInfo, buffers, cubeRotation, axisToRotate, modelViewMatrix, projectionMatrix) {
    
    mat4.rotate(modelViewMatrix,  // destination matrix
                modelViewMatrix,  // matrix to rotate
                cubeRotation,     // amount to rotate in radians
                axisToRotate);       // axis to rotate around   

    // Tell WebGL how to pull out the positions from the position
    // buffer into the vertexPosition attribute.
    {
        const numComponents = 3; // (x,y,z)
        const type = gl.FLOAT;
        const normalize = false;
        const stride = 0;
        const offset = 0;
        gl.bindBuffer(gl.ARRAY_BUFFER, buffers.position);
        gl.vertexAttribPointer(
            programInfo.attribLocations.vertexPosition,
            numComponents,
            type,
            normalize,
            stride,
            offset);
        gl.enableVertexAttribArray(
            programInfo.attribLocations.vertexPosition);
    }

    // Tell WebGL how to pull out the colors from the color buffer
    // into the vertexColor attribute.
    {
        const numComponents = 4; // (r,g,b,a)
        const type = gl.FLOAT;
        const normalize = false;
        const stride = 0;
        const offset = 0;
        gl.bindBuffer(gl.ARRAY_BUFFER, buffers.color);
        gl.vertexAttribPointer(
            programInfo.attribLocations.vertexColor,
            numComponents,
            type,
            normalize,
            stride,
            offset);
        gl.enableVertexAttribArray(
            programInfo.attribLocations.vertexColor);
    }


    // ** LIGHTING ** Start ---
    if (lightShade == true) {
        var normalMatrix = mat4.create();
        mat4.invert(normalMatrix, modelViewMatrix);
        mat4.transpose(normalMatrix, normalMatrix);

        // Tell WebGL how to pull out the normals from
        // the normal buffer into the vertexNormal attribute.
        {
            const numComponents = 3; // (x, y, z)
            const type = gl.FLOAT;
            const normalize = false;
            const stride = 0;
            const offset = 0;
            gl.bindBuffer(gl.ARRAY_BUFFER, buffers.normal);
            gl.vertexAttribPointer(
                programInfo.attribLocations.vertexNormal,
                numComponents,
                type,
                normalize,
                stride,
                offset);
            gl.enableVertexAttribArray(
                programInfo.attribLocations.vertexNormal);
        }    
    }
    // ** LIGHTING ** Finish ---

    // Tell WebGL which indices to use to index the vertices
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, buffers.indices);

    // Tell WebGL to use our program when drawing
    gl.useProgram(programInfo.program);

    // Set the shader uniforms
    gl.uniformMatrix4fv(
        programInfo.uniformLocations.projectionMatrix,
        false,
        projectionMatrix);
    gl.uniformMatrix4fv(
        programInfo.uniformLocations.modelViewMatrix,
        false,
        modelViewMatrix);

    // ** LIGHTING **    
    if (lightShade == true) {
        gl.uniformMatrix4fv(
            programInfo.uniformLocations.normalMatrix,
            false,
            normalMatrix);
    }
}

// ########################################### //
// Initialize a shader program, so WebGL knows how to draw our data
//
function initShaderProgram(gl, vsSource, fsSource) {
    const vertexShader = loadShader(gl, gl.VERTEX_SHADER, vsSource);
    const fragmentShader = loadShader(gl, gl.FRAGMENT_SHADER, fsSource);

    // Create the shader program
    const shaderProgram = gl.createProgram();
    gl.attachShader(shaderProgram, vertexShader);
    gl.attachShader(shaderProgram, fragmentShader);
    gl.linkProgram(shaderProgram);

    // If creating the shader program failed, alert
    if (!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS)) {
        alert('Unable to initialize the shader program: ' + gl.getProgramInfoLog(shaderProgram));
        return null;
    }

    return shaderProgram;
}

// ########################################### //
// creates a shader of the given type, uploads the source and
// compiles it.
//
function loadShader(gl, type, source) {
    const shader = gl.createShader(type);

    // Send the source to the shader object
    gl.shaderSource(shader, source);

    // Compile the shader program
    gl.compileShader(shader);

    // See if it compiled successfully
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        alert('An error occurred compiling the shaders: ' + gl.getShaderInfoLog(shader));
        gl.deleteShader(shader);
        return null;
    }

    return shader;
}


function changeHValue() {
    let hValue = parseInt(document.getElementById("hValue").value, 10);
    cubeRotation1 = hValue * 0.0174533;
    main();
}

function changeEValue() {
    let eValue = parseInt(document.getElementById("eValue").value, 10);
    earRotation = eValue * 0.0174533;
    main();
}

function changeRotateBValue() {
    let bValue = parseInt(document.getElementById("bValue").value, 10);
    cubeRotation2 = bValue * 0.0174533;
    main();
}

function changeSpinBValue() {
    let bValue = parseInt(document.getElementById("spinBValue").value, 10);
    cubeRotation3 = bValue * 0.0174533;
    main();
}

var animateBool = false, timer = 0, increase = true, increase1 = true;

function animateScene() {
    if (animateBool == false) { animateBool = true; }
    else { animateBool = false; }

    if (animateBool == true) {
        timer = setInterval(function(){ animateSceneLoop() }, 10);
        document.getElementById("A1").value = "Stop animate";
    } else {
        clearInterval(timer);
        document.getElementById("A1").value = "Animate";
    }
}

function animateSceneLoop() {
    let hValue = parseInt(document.getElementById("hValue").value, 10);
    let eValue = parseInt(document.getElementById("eValue").value, 10);

    if (hValue == 15) { increase = false; }
    else if (hValue == -15) { increase = true;  }

    if (increase == true) { hValue++; }
    else { hValue--; }

    if (eValue == 15) { increase1 = false; }
    else if (eValue == 0) { increase1 = true;  }

    if (increase == true) { eValue++; }
    else { eValue--; }
    
    
    document.getElementById("hValue").value = hValue;
    document.getElementById("eValue").value = eValue;
    cubeRotation1 = hValue * 0.0174533; 
    earRotation = eValue * 0.0174533;
    main();
}

// ** LIGHTING ** Start ---
// Light & Shade function - button "Light" & "Shade"
function toggleLightShade() {
    if (lightShade == false) {
        lightShade = true;
        document.getElementById("l1").value = "OFF Light";
        document.getElementById("l2").value = "OFF Shade";
    } else {
        lightShade = false;
        document.getElementById("l1").value = "Light";
        document.getElementById("l2").value = "Shade";
    }
    main();
}
// ** LIGHTING ** Finish ---